#pragma once
#include <openssl/bio.h>
#include <openssl/decoder.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef RSACipher_H
#define RSACipher_H

class LICENSING_API RSACipher {
public:
	RSACipher(std::string key, bool isPublic);
	RSACipher(RSACipher const&) = delete;
	~RSACipher();
	std::string encrypt(std::string data);
	std::vector<unsigned char> encrypt(std::vector<unsigned char> data);
	std::string decrypt(std::string data);
	std::vector<unsigned char> decrypt(std::vector<unsigned char> data);
	bool isFailed();
	RSACipher& operator=(RSACipher const&) = delete;
private:
	BIO* _bo;
	EVP_PKEY* _pKey;
	bool _isFailed = false;
};

#endif // RSACipher_H