#pragma once
#include <stduuid/uuid.h>
#include "IControlState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IServerState_H
#define IServerState_H

class LICENSING_API IServerState : public virtual IControlState
{
	using Guid = uuids::uuid;
public:
	virtual Guid get_InstanceId() = 0;
	virtual ReadOnlyCollection<OfflineCheckoutInfo> get_OfflineCheckouts() = 0;
};

#endif // IServerState_H

