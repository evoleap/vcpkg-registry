#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef PublicKeyFile_H
#define PublicKeyFile_H

class LICENSING_API PublicKeyFile
{
public:
	static PublicKeyFile* Create(std::string fileText);
	std::string get_FileText() const;
private:
	PublicKeyFile(std::string fileText);
#pragma warning(disable: 4251)
	std::string _fileText;
#pragma warning(default: 4251)
};

#endif // PublicKeyFile_H