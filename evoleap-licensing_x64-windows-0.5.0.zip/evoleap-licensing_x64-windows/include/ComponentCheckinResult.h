#pragma once
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ComponentCheckinResult_H
#define ComponentCheckinResult_H

enum class LICENSING_API ComponentCheckinFailureReason
{
    /// <summary>
    /// The reason is not known.
    /// </summary>
    Unknown = -1,
    /// <summary>
    /// The component checkout did not fail.
    /// </summary>
    NoFailure = 0,
    /// <summary>
    /// The server could not be reached.
    /// </summary>
    ServiceUnreachable
};

LICENSING_API std::istream& operator>>(std::istream& is, ComponentCheckinFailureReason& model);
LICENSING_API std::ostream& operator<<(std::ostream& os, ComponentCheckinFailureReason model);


class ComponentCheckinResult : public virtual IJsonSerializable
{
public:
    static LICENSING_API ComponentCheckinResult GetSuccess(bool processedOffline);
    static LICENSING_API ComponentCheckinResult GetFailure(ComponentCheckinFailureReason reason);
    /// <summary>
    /// If component checkout failed, gets a value indicating why the checkout failed.
    /// </summary>
    LICENSING_API ComponentCheckinFailureReason get_FailureReason();

    /// <summary>
    /// Gets a value indicating whether the component checkout was successful.
    /// </summary>
    LICENSING_API bool get_Success();

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    bool _Success;
    ComponentCheckinFailureReason _FailureReason;
    ComponentCheckinResult(bool success, ComponentCheckinFailureReason failureReason);
};

#endif // ComponentCheckinResult_H
