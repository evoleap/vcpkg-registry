#pragma once
#include "IJsonSerializable.h"
#include "ComponentInfo.h"
#include "ComponentEntitlementInfo.h"
#include "ReadOnlyCollection.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ComponentsStatus_H
#define ComponentsStatus_H

class LICENSING_API ComponentsStatus
{
public:
    ComponentsStatus();
    /// <summary>
    /// Gets a value indicating whether the component checkout was successful.
    /// </summary>
    bool get_Success();
    void set_Success(bool value);

    /// <summary>
    /// Gets details about the components that are available to the product.  If the call was successful, this
    /// value contains data returned by the server.  If the call was not successful, this value contains data
    /// stored from the most recent successful validation.
    /// </summary>
    ReadOnlyCollection<ComponentInfo> get_Components();
    void set_Components(ReadOnlyCollection<ComponentInfo> value);

    /// <summary>
    /// Gets details about the entitlements in force for each component.  If the call was not successful, this
    /// value is null.
    /// </summary>
    ReadOnlyCollection<ComponentEntitlementInfo> get_ComponentEntitlements();
    void set_ComponentEntitlements(ReadOnlyCollection<ComponentEntitlementInfo> value);
private:
    bool _Success;
    ReadOnlyCollection<ComponentInfo> _Components;
    ReadOnlyCollection<ComponentEntitlementInfo> _ComponentEntitlements;
};

#endif // ComponentsStatus_H