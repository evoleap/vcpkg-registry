#pragma once
#include "SessionValidity.h"
#include "EventHandler.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef SessionExtensionTimer_H
#define SessionExtensionTimer_H

class LICENSING_API SessionExtensionTimer
{
public:
	void Update(SessionValidity validity);
	void add_LicenseCheckNecessary(EventHandler handler);
	void remove_LicenseCheckNecessary(EventHandler handler);
private:
	SessionValidity _validity;
#pragma warning( disable : 4251 ) // The vector is internal to this class and not exposed, so we can safely ignore the warning.
	// std::vector < EventHandler, std::allocator<EventHandler>>' needs to have dll-interface to be used by clients of 'SessionExtensionTimer'
	std::vector<EventHandler> _licenseCheckNecessary;
#pragma warning( default : 4251 ) 
};

#endif // SessionExtensionTimer_H
