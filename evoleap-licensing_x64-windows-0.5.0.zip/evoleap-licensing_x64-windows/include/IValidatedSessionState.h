#pragma once
#include <string>
#include <stduuid/uuid.h>
#include "ReadOnlyCollection.h"
#include "SessionOfflineTokenCheckoutInfo.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IValidatedSessionState_H
#define IValidatedSessionState_H

class LICENSING_API IValidatedSessionState
{
public:
    /// <summary>
    /// Gets a value indicating what state the session is in.
    /// </summary>
    virtual int get_SessionState();
    /// <summary>
    /// Gets the authorization token representing the current session.
    /// </summary>
    virtual std::string get_AuthToken();
    /// <summary>
    /// Gets a unique value identifying the session to the server.
    /// </summary>
    virtual std::string get_SessionKey();
	virtual void set_SessionKey(std::string value);
    /// <summary>
    /// Gets a value indicating which offline checkout was used to start the session, if any.
    /// </summary>
    virtual std::string get_OfflineCheckoutKey();
    /// <summary>
    /// Gets a list of offline token checkouts that have been made for this session, if any.
    /// </summary>
    virtual ReadOnlyCollection<SessionOfflineTokenCheckoutInfo>& get_OfflineTokenCheckouts();
    /// <summary>
    /// Gets an ID identifying any offline session info for the current session.
    /// </summary>
    virtual uuids::uuid get_OfflineSessionID();
    /// <summary>
    /// Construct objects.
    /// </summary>
    IValidatedSessionState();
    /// <summary>
    /// Destroy objects.
    /// </summary>
    ~IValidatedSessionState();
protected:
#pragma warning(disable: 4251)
    int _sessionState;
	std::string _authToken;
	std::string _sessionKey;
	std::string _offlineCheckoutKey;
	ReadOnlyCollection<SessionOfflineTokenCheckoutInfo>* _offlineTokenCheckouts;
	uuids::uuid _offlineSessionID;
#pragma warning(default: 4251)
};

#endif // IValidatedSessionState_H
