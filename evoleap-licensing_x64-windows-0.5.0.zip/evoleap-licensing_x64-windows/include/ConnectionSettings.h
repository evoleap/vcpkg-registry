#pragma once
#include <string>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

//extern "C" LICENSING_API void set_UserAgent(const std::string userAgent);
//
//extern "C" LICENSING_API std::string get_UserAgent();

#ifndef ConnectionSettings_H
#define ConnectionSettings_H

class LICENSING_API ConnectionSettings
{
public:
	static void set_UserAgent(const std::string userAgent);
	static std::string get_UserAgent();
	static void set_Host(const std::string host);
	static std::string get_Host();
private: // Static class. No constructors.
	ConnectionSettings();
	~ConnectionSettings();
};

#endif // ConnectionSettings_H