#pragma once
#include <map>
#include <string>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef UserIdentity_H
#define UserIdentity_H

class LICENSING_API UserIdentity
{
public:
	static const int DefaultVersion = 1;
	int get_Version();
	UserIdentity(int version = DefaultVersion);
	UserIdentity(std::map<std::string, std::string> data, int version = DefaultVersion);
	const std::map<std::string, std::string>& get_Data();
private:
	int _version;
#pragma warning(disable: 4251)
	std::map<std::string, std::string> _data;
#pragma warning(default: 4251)
};

#endif // UserIdentity_H