#pragma once
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef TimeProvider_H
#define TimeProvider_H

class LICENSING_API TimeProvider
{
public:
	TimeProvider();
	virtual ~TimeProvider();
	virtual UTCDateTime get_UtcNow() const;

	TimeProvider& operator=(const TimeProvider&);

	static void setCurrent(TimeProvider &value);
	static TimeProvider& getCurrent();
	static TimeProvider& getDefault();
};

class LICENSING_API SystemTimeProvider : public TimeProvider
{
public:
	SystemTimeProvider();
	~SystemTimeProvider();
	UTCDateTime get_UtcNow() const override;
};

#endif // !TimeProvider_H