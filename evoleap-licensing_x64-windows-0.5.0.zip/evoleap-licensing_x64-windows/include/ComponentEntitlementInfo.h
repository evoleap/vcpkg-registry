#pragma once
#include <string>
#include <vector>
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ComponentEntitlementInfo_H
#define ComponentEntitlementInfo_H

class LICENSING_API TokenUsage : public virtual IJsonSerializable {
public:
    TokenUsage();
    int get_TokensEntitled();
    void set_TokensEntitled(int value);
    int get_TokensInUse();
    void set_TokensInUse(int value);
    int get_TokensInUseBySession();
    void set_TokensInUseBySession(int value);
    int get_TokensCheckedOutByInstance();
    void set_TokensCheckedOutByInstance(int value);

	bool operator==(const TokenUsage& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    int _TokensEntitled;
    int _TokensInUse;
    int _TokensInUseBySession;
    int _TokensCheckedOutByInstance;
};

class LICENSING_API SessionUsage : public virtual IJsonSerializable {
public:
    SessionUsage();
    int get_SessionsEntitled();
    void set_SessionsEntitled(int value);
    int get_SessionsInUse();
    void set_SessionsInUse(int value);
    bool get_InUseBySession();
    void set_InUseBySession(bool value);

	bool operator==(const SessionUsage& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    int _SessionsEntitled;
    int _SessionsInUse;
    bool _InUseBySession;
};

class LICENSING_API CurrencyUsage : public virtual IJsonSerializable {
public:
    CurrencyUsage();
    int get_CurrencyEntitled();
    void set_CurrencyEntitled(int value);
    int get_CurrencyUsed();
    void set_CurrencyUsed(int value);

	bool operator==(const CurrencyUsage& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    int _CurrencyEntitled;
    int _CurrencyUsed;
};

class LICENSING_API ComponentEntitlementInfo : public virtual IJsonSerializable
{
public:
	ComponentEntitlementInfo();
    int get_ID();
    void set_ID(int value);
    std::vector<std::string> get_Components();
    void set_Components(std::vector<std::string> value);
    TokenUsage get_TokenUsage();
    void set_TokenUsage(TokenUsage value);
    SessionUsage get_SessionUsage();
    void set_SessionUsage(SessionUsage value);
    CurrencyUsage get_CurrencyUsage();
    void set_CurrencyUsage(CurrencyUsage value);

	bool operator==(const ComponentEntitlementInfo& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    int _ID;
#pragma warning(disable: 4251)
    std::vector<std::string> _Components;
#pragma warning(default: 4251)
    TokenUsage _TokenUsage;
    SessionUsage _SessionUsage;
    CurrencyUsage _CurrencyUsage;
};

#endif // ComponentEntitlementInfo_H