#pragma once
#include <map>
#include "ci_less.h"
#include "InstanceIdentityValue.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ExtensibleDictionary_H
#define ExtensibleDictionary_H
//ExtensibleDictionary<std::string, InstanceIdentityValue>
template<class TKey, class TValue, class TCompare = std::less<TKey>> class ExtensibleDictionary
{
public:
	using MapType = std::map<TKey, TValue, TCompare>;
	using Iterator = typename MapType::iterator;
	ExtensibleDictionary();
	virtual ~ExtensibleDictionary();
	virtual size_t get_Count();
	virtual void Add(TKey key, TValue value);
	virtual TValue operator[](TKey key);
	virtual void insert(const TKey& key, const TValue& value);
	virtual Iterator begin();
	virtual Iterator end();
protected:
	virtual void AddItem(TKey key, TValue value);
	virtual void SetItem(TKey key, TValue value);
	virtual void RemoveItem(TKey key);
	virtual void ClearItems();
private:
// This is not really exposed outside the DLL, but you get about a million warnings about it being exposed which is crap, so disabling the warning.
//#pragma warning( disable : 4251 )
	std::map<TKey, TValue, TCompare>* _storage;
};

template class LICENSING_API ExtensibleDictionary<std::string, InstanceIdentityValue, ci_less>;

#endif // ExtensibleDictionary_H