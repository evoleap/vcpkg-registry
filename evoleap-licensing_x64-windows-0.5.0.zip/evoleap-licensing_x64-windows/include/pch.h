// pch.h: This is a precompiled header file.
// Files listed below are compiled only once, improving build performance for future builds.
// This also affects IntelliSense performance, including code completion and many code browsing features.
// However, files listed here are ALL re-compiled if any one of them is updated between builds.
// Do not add files here that you will be updating frequently as this negates the performance advantage.

#ifndef PCH_H
#define PCH_H

// TODO: Right now all headers are global in this file and are included in all .cpp files. Eventually, we probably need to separate out the header includes
// because this means that if ConnectionSettiongs.h includes <string>, then other .h files may not because it all compiled. So splitting this out will 
// force each header file to include everything it needs for itself. This way consumers of the .h files won't get compile errors for missing includes.

// add headers that you want to pre-compile here
#include "UUIDHelper.h"
#include "framework.h"
#include "ConnectionSettings.h"
#include "TimeProvider.h"
#include "UTCDateTime.h"
#include "WebServiceConstants.h"
#include "InstanceIdentityValue.h"
#include "ExtensibleDictionary.h"
#include "InstanceIdentityValueDictionary.h"
#include "ci_less.h"
#include "InstanceIdentity.h"
#include "HardwareBasedInstanceIdentity.h"
#include "SessionExtensionTimer.h"
#include "EventHandler.h"
#include "SessionValidity.h"
#include "HttpClient.h"
#include "WebHelper.h"
#include "IJsonSerializable.h"
#include "ReadOnlyCollection.h"
#include "SessionOfflineTokenCheckoutInfo.h"
#include "base64class.h"
#include "RSACipher.h"
#include "Version.h"
#include "PublicKeyFile.h"
#include "UserIdentity.h"
#include "ActiveDirectoryBasedUserIdentity.h"
#include "ControlStrategy.h"
#include "IValidationState.h"
#include "IValidatedSessionState.h"
#include "ServerResults.h"
#include "ILicensingWebService.h"
#include "DisallowReentrancyMarker.h"
#include "ValidationState.h"
#include "ValidatedSessionState.h"
#include "LicensingWebService.h"
#include "UserInfo.h"
#include "RegistrationResult.h"
#include "ControlManagerHelper.h"
#include "ControlManager.h"
#include "WebServiceConstants.h"

// Predefine these classes so they are compiled into the DLL and so linking will work
template class LICENSING_API ReadOnlyCollectionBase<ComponentInfo>;
template class LICENSING_API ReadOnlyCollection<ComponentInfo>;
template class LICENSING_API ReadOnlyCollectionBase<ComponentEntitlementInfo>;
template class LICENSING_API ReadOnlyCollection<ComponentEntitlementInfo>;
template class LICENSING_API ReadOnlyCollectionBase<OfflineCheckoutInfo>;
template class LICENSING_API ReadOnlyCollection<OfflineCheckoutInfo>;
template class LICENSING_API ReadOnlyCollectionBase<OfflineSessionInfo>;
template class LICENSING_API ReadOnlyCollection<OfflineSessionInfo>;
//template ComponentLicenseModel IJsonSerializable::getEnumValue(std::string value);

#ifdef _WIN32
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "Ws2_32.lib")
#endif

#endif //PCH_H
