#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef HttpClient_H
#define HttpClient_H

class LICENSING_API HttpClient
{
public:
	virtual std::string Get(const std::string& url);
	virtual std::string Post(const std::string& url, const std::string& data);
};

#endif // HttpClient_H
