#pragma once
#include <string>
#include "IControlState.h"
#include "ILicensingWebService.h"
#include "ServerResults.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ControlState_H
#define ControlState_H

template class ReadOnlyCollection<UTCDateTime>;

class ControlState :
    virtual public IControlState //, IJsonSerializable
{
public:
    ControlState();
    ControlState(IControlState* other);
	virtual void AdditionalUpdateAfterRegistrationSuccess(RegisterResultBase* result);

    // Inherited via IControlState
    bool get_Registered() override;
    ReadOnlyCollection<std::chrono::system_clock::time_point> get_FailedRegistrationTimes() override;
    std::optional<std::chrono::system_clock::time_point> get_RegisteredAt() override;
    std::chrono::system_clock::time_point get_FirstLaunchTime() override;
    ReadOnlyCollection<std::chrono::system_clock::time_point> get_FailedValidationTimes() override;
    ReadOnlyCollection<UTCDateTime> get_FailedValidationTimesUTC();
    std::optional<std::chrono::system_clock::time_point> get_LastSuccessfulValidationTime() override;
    int get_LastValidationStatus() override;
    ReadOnlyCollection<std::string> get_Features() override;
    ReadOnlyCollection<std::string> get_FeatureGroups() override;
    std::chrono::duration<double, std::milli> get_GracePeriodForValidationFailures() override;
    // Set methods for direct reference to class
	void set_Registered(bool value);
	void set_RegisteredAt(std::optional<std::chrono::system_clock::time_point> value);
	void set_FirstLaunchTime(std::chrono::system_clock::time_point value);
	void set_LastSuccessfulValidationTime(std::optional<std::chrono::system_clock::time_point> value);
	void set_LastValidationStatus(ValidationStatus value);
	void set_GracePeriodForValidationFailures(std::chrono::duration<double, std::milli> value);
	void set_Features(std::vector<std::string> value);
	void set_FeatureGroups(std::vector<std::string> value);
	void clear_FailedRegistrationTimes();
    void set_FailedValidationTimes(ReadOnlyCollection<std::chrono::system_clock::time_point> value);
    std::vector<std::chrono::system_clock::time_point>* get_FailedRegistrationTimesInternal();
    // Inherited via IJsonSerializable
    //void Serialize(Json::Value& root) override;
    //void Deserialize(Json::Value& root) override;
private:
	bool _registered;
	std::vector<std::chrono::system_clock::time_point> _failedRegistrationTimes;
	std::optional<std::chrono::system_clock::time_point> _registeredAt;
	std::chrono::system_clock::time_point _firstLaunchTime;
    std::vector<std::chrono::system_clock::time_point> _failedValidationTimes;
	std::optional<std::chrono::system_clock::time_point> _lastSuccessfulValidationTime;
	ValidationStatus _lastValidationStatus;
    std::vector<std::string> _features;
    std::vector<std::string> _featureGroups;
	std::chrono::duration<double, std::milli> _gracePeriodForValidationFailures;
};

#endif // ControlState_H
