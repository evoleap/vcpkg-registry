#pragma once
#include <optional>
#include <stduuid/uuid.h>
#include <vector>
#include "ComponentInfo.h"
#include "ComponentEntitlementInfo.h"
#include "IValidationState.h"
#include "OfflineSessionInfo.h"
#include "OfflineTokenCheckoutInfo.h"
#include "SessionControlState.h"
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ValidationState_H
#define ValidationState_H

template class ReadOnlyCollection<OfflineTokenCheckoutInfo>;

#pragma warning(disable: 4250) // The ControlState/SessionControlState implementation of IControlState is inherited by ValidationState, overriding the virtual
							   // functions in ISessionControlState/IControlState/IValidationState. This warning is disabled because it is by design.

class ValidationState :
    virtual public IValidationState, public SessionControlState
{
	using Guid = uuids::uuid;
public: // This is an internal implementation, exposed through IValidationState
	ValidationState(IValidationState* state);
	ValidationState();
	~ValidationState();
	void CleanOfflineCheckouts(UTCDateTime timeNow);

	void set_InstanceId(Guid value);
	void set_UserId(std::optional<Guid> value);

	std::vector<ComponentInfo> get_ComponentsRW();
	void set_Components(std::vector<ComponentInfo> value);
	std::vector<ComponentInfo> ComponentsIfLoaded();

	std::vector<ComponentEntitlementInfo> get_EntitlementsRW();
	void set_Entitlements(std::vector<ComponentEntitlementInfo> value);
	std::vector<ComponentEntitlementInfo> ComponentEntitlementsIfLoaded();
    void set_ComponentsLoaded(bool value);
    void set_ComponentEntitlementsLoaded(bool value);

	std::vector<OfflineSessionInfo> get_OfflineSessionsRW();
	void set_OfflineSessions(std::vector<OfflineSessionInfo> value);
	std::optional<OfflineSessionInfo> OfflineSession(Guid id);

	void set_OfflineCheckouts(ReadOnlyCollection<OfflineCheckoutInfo> value);

	bool HasExpiredOfflineCheckout(UTCDateTime timeNow);
	OfflineCheckoutInfo OfflineCheckout(std::string checkoutKey, bool* found);

	void AdditionalUpdateAfterRegistrationSuccess(RegisterResultBase* result) override;

	void CleanOfflineTokenCheckouts(UTCDateTime timeNow);
	void set_OfflineTokenCheckouts(ReadOnlyCollection<OfflineTokenCheckoutInfo> value);
};

#pragma warning(default: 4250)

#endif // ValidationState_H
