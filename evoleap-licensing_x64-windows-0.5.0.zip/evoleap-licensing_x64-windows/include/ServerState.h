#pragma once
#include <stduuid/uuid.h>
#include "ControlState.h"
#include "IServerState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ServerState_H
#define ServerState_H

#pragma warning(disable: 4250) // The ControlState implementation of IControlState is inherited by ServerState, overriding the virtual functions
							   // in ISessionControlState/IControlState. This warning is disabled because it is by design.

class ServerState : public ControlState, public virtual IServerState
{
	using Guid = uuids::uuid;
public:
	ServerState();
	ServerState(IServerState* other);

    Guid get_InstanceId() override;
    void set_InstanceId(Guid value);

	void AdditionalUpdateAfterRegistrationSuccess(RegisterResultBase* result) override;

	/// <summary>
    /// A list of all offline checkouts.
    /// </summary>
    ReadOnlyCollection<OfflineCheckoutInfo> get_OfflineCheckouts() override;
	void set_OfflineCheckouts(ReadOnlyCollection<OfflineCheckoutInfo> value);
	void CleanOfflineCheckouts(UTCDateTime timeNow);

private:
	Guid _InstanceId;
	ReadOnlyCollection<OfflineCheckoutInfo> _offlineCheckouts;
};

#pragma warning(default: 4250)

#endif // ServerState_H