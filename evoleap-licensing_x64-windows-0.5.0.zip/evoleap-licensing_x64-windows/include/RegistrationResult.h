#pragma once
#include <string>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef RegistrationResult_H
#define RegistrationResult_H

class RegistrationResult
{
public:
	LICENSING_API RegistrationResult(bool success, std::string errorMessage);
	LICENSING_API ~RegistrationResult();
	LICENSING_API bool get_Success();
	LICENSING_API std::string get_ErrorMessage();
	static LICENSING_API RegistrationResult GetSuccess();
	static LICENSING_API RegistrationResult GetError(std::string errorMessage);
private:
	bool _success;
	std::string _errorMessage;
};

#endif // RegistrationResult_H