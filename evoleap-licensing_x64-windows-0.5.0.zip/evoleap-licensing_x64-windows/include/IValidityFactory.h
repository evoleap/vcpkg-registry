#pragma once
#include <optional>
#include "InstanceValidity.h"
#include "SessionValidity.h"
#include "UtcDateTime.h"

using TimeSpan = std::chrono::duration<double, std::milli>;

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IValidityFactory_H
#define IValidityFactory_H

template<typename TValidity> class LICENSING_API IValidityFactory
{
public:
    virtual TValidity Invalid(InvalidReason reason) = 0;
    virtual TValidity UnregisteredGracePeriod(UTCDateTime expiration) = 0;
    virtual TValidity ValidationFailureGracePeriod(UTCDateTime expiration) = 0;
    virtual TValidity Valid(std::optional<TimeSpan> validityDuration) = 0;
};

template<typename T> class ValidityFactory : public virtual IValidityFactory<T>
{
public:
private:
    ValidityFactory();
};

template<> class LICENSING_API ValidityFactory<InstanceValidity> : public virtual IValidityFactory<InstanceValidity>
{
public:
	static ValidityFactory<InstanceValidity>& ForInstanceValidity();
	InstanceValidity Invalid(InvalidReason reason) override;
	InstanceValidity UnregisteredGracePeriod(UTCDateTime expiration) override;
	InstanceValidity ValidationFailureGracePeriod(UTCDateTime expiration) override;
	InstanceValidity Valid(std::optional<TimeSpan> validityDuration) override;
};

template<> class LICENSING_API ValidityFactory<SessionValidity> : public virtual IValidityFactory<SessionValidity>
{
public:
	static ValidityFactory<SessionValidity>& ForSessionValidity();
	SessionValidity Invalid(InvalidReason reason) override;
	SessionValidity UnregisteredGracePeriod(UTCDateTime expiration) override;
	SessionValidity ValidationFailureGracePeriod(UTCDateTime expiration) override;
	SessionValidity Valid(std::optional<TimeSpan> validityDuration) override;
};

// Export these specific template classes (the only ones that are valid)
template class LICENSING_API IValidityFactory<InstanceValidity>;
template class LICENSING_API IValidityFactory<SessionValidity>;
template class LICENSING_API ValidityFactory<InstanceValidity>;
template class LICENSING_API ValidityFactory<SessionValidity>;

#endif // IValidityFactory_H