#pragma once
#include <string>
#include <vector>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef OfflineCheckoutInfo_H
#define OfflineCheckoutInfo_H


class OfflineCheckoutInfo
{
public:
	using DateTime = std::chrono::system_clock::time_point;
	using TimeSpan = std::chrono::duration<double, std::milli>;
    LICENSING_API std::string get_CheckoutKey();
    LICENSING_API void set_CheckoutKey(std::string value);
    LICENSING_API DateTime get_Expiration();
    LICENSING_API void set_Expiration(DateTime value);
    LICENSING_API std::vector<std::string> get_Features();
    LICENSING_API void set_Features(std::vector<std::string> value);
    LICENSING_API std::vector<std::string> get_FeatureGroups();
    LICENSING_API void set_FeatureGroups(std::vector<std::string> value);
    LICENSING_API bool IsActive(UTCDateTime timeNow);
    LICENSING_API bool ShouldBeRemoved(UTCDateTime timeNow);
    LICENSING_API static TimeSpan get_RemovalGracePeriod();
	LICENSING_API bool operator==(OfflineCheckoutInfo& other);
private:
    std::string _CheckoutKey;
    DateTime _Expiration;
    std::vector<std::string> _Features;
    std::vector<std::string> _FeatureGroups;
};

#endif // OfflineCheckoutInfo_H