#pragma once
#include <string>
#include <optional>
#include <stduuid/uuid.h>
#include "ComponentEntitlementInfo.h"
#include "ComponentInfo.h"
#include "FullLicense.h"
#include "UTCDateTime.h"
#include "WebServiceConstants.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ServerResultClasses_H
#define ServerResultClasses_H

using TimeSpan = std::chrono::duration<double, std::milli>;
using DateTime = std::chrono::system_clock::time_point;

extern WebServiceConstants CONSTANTS;

enum struct LICENSING_API ValidationStatus
{
    /// <summary>
        /// Returned when registration is required before starting a session.
        /// </summary>
    RegistrationRequired = -101,
    UserTamperingDetected = -100,
    ServiceUnreachable = -99,

    // Statuses above this line are client-only.
    // --------------
    // Statuses below this line are sent by the server
    FullLicenseAlreadyCheckedOut = -17,
    OfflineCheckoutNotSupported = -16,
    InvalidComponent = -15,
    InsufficientTokens = -14,
    ActivationPending = -13,
    SessionRevoked = -12,
    NoSeatsAvailable = -11,
    InconsistentRegistration = -10,
    InconsistentUser = -9,
    InstanceNotRegistered = -8,
    UserNotRegistered = -7,
    InvalidLicenseKey = -6,
    InvalidProductId = -5,
    InstanceDisabled = -4,
    UserDisabled = -3,
    LicenseExpired = -2,
    GeneralError = -1,
    Success = 0,
};

LICENSING_API std::istream& operator>>(std::istream& is, ValidationStatus& model);
LICENSING_API std::ostream& operator<<(std::ostream& os, ValidationStatus model);

class ServerResult : public virtual IJsonSerializable
{
public:
    /// <summary>
    /// Gets the error message if the call was unsuccessful.
    /// </summary>
    LICENSING_API std::string get_ErrorMessage();
    LICENSING_API void set_ErrorMessage(std::string value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::string _errorMessage;
};

class TimedServerResult : public ServerResult
{
public:
    /// <summary>
    /// Gets the server time if the server was contacted.
    /// </summary>
    LICENSING_API std::optional<UTCDateTime> get_ServerTime();
    LICENSING_API void set_ServerTime(std::optional<UTCDateTime> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::optional<UTCDateTime> _serverTime;
};

class RegisterResultBase : public TimedServerResult
{
public:
    /// <summary>
    /// Gets whether registration was successful.
    /// </summary>
    LICENSING_API bool get_Success();
    LICENSING_API void set_Success(bool value);
    /// <summary>
    /// Gets the grace period allowed for validation failures.
    /// </summary>
    LICENSING_API std::chrono::duration<double, std::milli> get_GracePeriodForValidationFailures();
    LICENSING_API void set_GracePeriodForValidationFailures(std::chrono::duration<double, std::milli> value);
    /// <summary>
    /// Gets the time at which this instance and/or user was *first* registered.  Multiple registrations
    /// of an instance are valid and will succeed, but this property will always return
    /// the time of the very first registration.  This is useful for determining the length
    /// of trial periods, for example.
    /// </summary>
    LICENSING_API std::optional<UTCDateTime> get_FirstRegisteredAt();
    LICENSING_API void set_FirstRegisteredAt(std::optional<UTCDateTime> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
	bool _success = false;
	std::chrono::duration<double, std::milli> _gracePeriodForValidationFailures;
	std::optional<UTCDateTime> _firstRegisteredAt;
};

class RegisterInstanceResultBase {
public:
    /// <summary>
    /// Returns the instance ID (a GUID) for the newly-registered instance.
    /// </summary>
    LICENSING_API uuids::uuid get_InstanceId();
    /// <summary>
    /// Sets the instance ID
    /// </summary>
    /// <param name="value">The instance id to set</param>
    LICENSING_API void set_InstanceId(uuids::uuid value);

    LICENSING_API virtual void Serialize(Json::Value& root) const;
    LICENSING_API virtual void Deserialize(Json::Value& root);
protected:
    uuids::uuid _instanceId;
};

class RegisterInstanceResult : public virtual RegisterResultBase, public virtual RegisterInstanceResultBase
{
public:
    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
};

class RegisterResultWithSessionDuration : public RegisterResultBase
{
public:
    /// <summary>
    /// Gets the length of time the session is active, from when the call was processed by the server.
    /// </summary>
    LICENSING_API std::chrono::duration<double, std::milli> get_SessionDuration();
    LICENSING_API void set_SessionDuration(std::chrono::duration<double, std::milli> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::chrono::duration<double, std::milli> _sessionDuration;

};

class RegisterUserResult : public RegisterResultWithSessionDuration
{
public:
    /// <summary>
    /// Returns the user ID (a GUID) for the newly-registered user.
    /// </summary>
    LICENSING_API uuids::uuid get_UserId();
    /// <summary>
    /// Sets the user ID
    /// </summary>
    /// <param name="value">The user id to set</param>
    LICENSING_API void set_UserId(uuids::uuid value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    uuids::uuid _userId;

};

class RegisterAppResult : public RegisterUserResult, public virtual RegisterInstanceResultBase
{
public:
    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
};

class ValidatedResult : public TimedServerResult
{
public:
    /// <summary>
    /// Gets the status of the current instance and validation call.
    /// </summary>
    LICENSING_API ValidationStatus get_Status();
    LICENSING_API void set_Status(ValidationStatus value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    ValidationStatus _Status;
};

class ValidatedSessionResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the current authorization token.
    /// </summary>
    LICENSING_API std::string get_AuthToken();
    LICENSING_API void set_AuthToken(std::string value);
    /// <summary>
    /// Gets the features currently active for the instance, if the call
    /// was successful.
    /// </summary>
    LICENSING_API std::vector<std::string> get_Features();
    LICENSING_API void set_Features(std::vector<std::string> value);
    /// <summary>
    /// Gets the feature groups currently active for the instance
    /// </summary>
    LICENSING_API std::vector<std::string> get_FeatureGroups();
    LICENSING_API void set_FeatureGroups(std::vector<std::string> value);
    /// <summary>
    /// Gets the grace period allowed for validation failures.
    /// </summary>
    LICENSING_API TimeSpan get_GracePeriodForValidationFailures();
    LICENSING_API void set_GracePeriodForValidationFailures(TimeSpan value);
    /// <summary>
    /// Gets the length of time the session is active, from when the call was processed by the server.
    /// </summary>
    LICENSING_API TimeSpan get_SessionDuration();
    LICENSING_API void set_SessionDuration(TimeSpan value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::string _AuthToken;
    std::vector<std::string> _Features;
    std::vector<std::string> _FeatureGroups;
    TimeSpan _GracePeriodForValidationFailures;
    TimeSpan _SessionDuration;
};

class BeginSessionResult : public ValidatedSessionResult
{
public:
    /// <summary>
    /// Gets a unique key identifying the session on the web service.
    /// </summary>
    LICENSING_API std::string get_SessionKey();
    LICENSING_API void set_SessionKey(std::string value);

    /// <summary>
    /// Gets the components that are available to this session.
    /// </summary>
    LICENSING_API std::vector<ComponentInfo> get_Components();
    LICENSING_API void set_Components(std::vector<ComponentInfo> value);
    /// <summary>
    /// Gets the status of component entitlements.
    /// </summary>
    LICENSING_API std::vector<ComponentEntitlementInfo> get_ComponentEntitlements();
    LICENSING_API void set_ComponentEntitlements(std::vector<ComponentEntitlementInfo> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::string _SessionKey;
    std::vector<ComponentInfo> _Components;
    std::vector<ComponentEntitlementInfo> _ComponentEntitlements;
};

class BeginAppSessionResult : public BeginSessionResult
{
public:
    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
};

class ExtendSessionResult : public ValidatedSessionResult
{
};

class EndSessionResult : public TimedServerResult
{
public:
    /// <summary>
    /// Gets whether the call succeeded.
    /// </summary>
    LICENSING_API bool get_Success();
    LICENSING_API void set_Success(bool value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    bool _Success;
};

class ValidateInstanceResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the grace period allowed for validation failures.
    /// </summary>
    LICENSING_API TimeSpan get_GracePeriodForValidationFailures();
    LICENSING_API void set_GracePeriodForValidationFailures(TimeSpan value);
    /// <summary>
    /// Gets the list of features currently active for the instance, if the call
    /// was successful.
    /// </summary>
    LICENSING_API std::vector<std::string> get_Features();
    LICENSING_API void set_Features(std::vector<std::string> value);
    /// <summary>
    /// Gets the feature groups currently active for the instance
    /// </summary>
    LICENSING_API std::vector<std::string> get_FeatureGroups();
    LICENSING_API void set_FeatureGroups(std::vector<std::string> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    TimeSpan _GracePeriodForValidationFailures;
    std::vector<std::string> _Features;
    std::vector<std::string> _FeatureGroups;
};

class ComponentsStatusResult : public ServerResult
{
public:
    /// <summary>
    /// Whether the server successfully returned a result.
    /// </summary>
    LICENSING_API bool get_Success();
    LICENSING_API void set_Success(bool value);
    /// <summary>
    /// Gets the status of individual components.
    /// </summary>
    LICENSING_API std::vector<ComponentInfo> get_Components();
    LICENSING_API void set_Components(std::vector<ComponentInfo> value);
    /// <summary>
    /// Gets the status of component entitlements.
    /// </summary>
    LICENSING_API std::vector<ComponentEntitlementInfo> get_ComponentEntitlements();
    LICENSING_API void set_ComponentEntitlements(std::vector<ComponentEntitlementInfo> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    bool _Success;
    std::vector<ComponentInfo> _Components;
    std::vector<ComponentEntitlementInfo> _ComponentEntitlements;
};

class component : public virtual IJsonSerializable
{
public:
    LICENSING_API std::string get_name() const;
    LICENSING_API void set_name(std::string value);
    LICENSING_API std::string get_license_model() const;
    LICENSING_API void set_license_model(std::string value);
    LICENSING_API int get_tokens_required() const;
    LICENSING_API void set_tokens_required(int value);
    LICENSING_API bool get_free_trial() const;
    LICENSING_API void set_free_trial(bool value);
    LICENSING_API std::string get_free_trial_expiration() const;
    LICENSING_API void set_free_trial_expiration(std::string value);
    LICENSING_API int get_original_tokens_required() const;
    LICENSING_API void set_original_tokens_required(int value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
    LICENSING_API UTCDateTime get_FreeTrialExpirationTime() const;
    LICENSING_API ComponentInfo ToComponentInfo() const;
    LICENSING_API ComponentLicenseModel get_ComponentLicenseModel() const;
private:
    std::string _name;
    std::string _license_model;
    int _tokens_required = 0;
    bool _free_trial = false;
    std::string _free_trial_expiration;
    int _original_tokens_required = 0;
};

class component_entitlement : public virtual IJsonSerializable
{
public:
    LICENSING_API int get_id() const;
    LICENSING_API void set_id(int value);
    LICENSING_API std::vector<std::string> get_components() const;
    LICENSING_API void set_components(std::vector<std::string> value);
    LICENSING_API int get_tokens_entitled() const;
    LICENSING_API void set_tokens_entitled(int value);
    LICENSING_API int get_tokens_in_use() const;
    LICENSING_API void set_tokens_in_use(int value);
    LICENSING_API int get_tokens_in_use_by_session() const;
    LICENSING_API void set_tokens_in_use_by_session(int value);
    LICENSING_API int get_tokens_checked_out() const;
    LICENSING_API void set_tokens_checked_out(int value);
    LICENSING_API int get_sessions_entitled() const;
    LICENSING_API void set_sessions_entitled(int value);
    LICENSING_API int get_sessions_in_use() const;
    LICENSING_API void set_sessions_in_use(int value);
    LICENSING_API bool get_in_use_by_session() const;
    LICENSING_API void set_in_use_by_session(bool value);
    LICENSING_API int get_currency_used() const;
    LICENSING_API void set_currency_used(int value);
    LICENSING_API int get_currency_entitled() const;
    LICENSING_API void set_currency_entitled(int value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
    LICENSING_API ComponentEntitlementInfo ToComponentEntitlementInfo() const;
private:
    int _id = 0;
    std::vector<std::string> _components;
    int _tokens_entitled = 0;
    int _tokens_in_use = 0;
    int _tokens_in_use_by_session = 0;
    int _tokens_checked_out = 0;
    int _sessions_entitled = 0;
    int _sessions_in_use = 0;
    bool _in_use_by_session = false;
    int _currency_used = 0;
    int _currency_entitled = 0;
};

class components_status : public virtual IJsonSerializable
{
public:
    LICENSING_API std::vector<component> get_components();
    LICENSING_API void set_components(std::vector<component> value);
    LICENSING_API std::vector<ComponentInfo> ToComponentInfos();

    LICENSING_API std::vector<component_entitlement> get_component_entitlements();
    LICENSING_API void set_component_entitlements(std::vector<component_entitlement> value);
    LICENSING_API std::vector<ComponentEntitlementInfo> ToComponentEntitlementInfos();

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::vector<component> _components;
    std::vector<component_entitlement> _component_entitlements;
};

class CheckOutComponentResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the status of individual components.
    /// </summary>
    LICENSING_API std::vector<ComponentInfo> get_Components() const;
    LICENSING_API void set_Components(std::vector<ComponentInfo> value);
    /// <summary>
    /// Gets the status of component entitlements.
    /// </summary>
    LICENSING_API std::vector<ComponentEntitlementInfo> get_ComponentEntitlements() const;
    LICENSING_API void set_ComponentEntitlements(std::vector<ComponentEntitlementInfo> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::vector<ComponentInfo> _Components;
    std::vector<ComponentEntitlementInfo> _ComponentEntitlements;
};


class CheckInComponentResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the status of individual components.
    /// </summary>
    LICENSING_API std::vector<ComponentInfo> get_Components() const;
    LICENSING_API void set_Components(std::vector<ComponentInfo> value);
    /// <summary>
    /// Gets the status of component entitlements.
    /// </summary>
    LICENSING_API std::vector<ComponentEntitlementInfo> get_ComponentEntitlements() const;
    LICENSING_API void set_ComponentEntitlements(std::vector<ComponentEntitlementInfo> value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::vector<ComponentInfo> _Components;
    std::vector<ComponentEntitlementInfo> _ComponentEntitlements;
};

class CheckOutLicenseResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the key identifying the checkout.
    /// </summary>
    LICENSING_API std::string get_CheckoutKey() const;
    LICENSING_API void set_CheckoutKey(std::string value);

    /// <summary>
    /// Gets the time when the checkout expires.
    /// </summary>
    LICENSING_API UTCDateTime get_ExpirationTime() const;
    LICENSING_API void set_ExpirationTime(UTCDateTime value);

    /// <summary>
    /// Gets the features currently active for the instance, if the call
    /// was successful.
    /// </summary>
    LICENSING_API std::vector<std::string> get_Features() const;
    LICENSING_API void set_Features(std::vector<std::string> value);
    /// <summary>
    /// Gets the feature groups currently active for the instance
    /// </summary>
    LICENSING_API std::vector<std::string> get_FeatureGroups() const;
    LICENSING_API void set_FeatureGroups(std::vector<std::string> value);

    /// <summary>
    /// Full license JSON document, signed by checksum
    /// </summary>
    LICENSING_API std::string get_FullLicenseJSON() const;
    LICENSING_API void set_FullLicenseJSON(std::string value);

    /// <summary>
    /// Full license checked out, stored in object structure from JSON
    /// </summary>
    LICENSING_API FullLicense get_FullLicense() const;
    //void set_FullLicense(FullLicense value);

    /// <summary>
    /// Checksum of full license JSON document
    /// </summary>
    LICENSING_API std::string get_FullLicenseChecksum() const;
    LICENSING_API void set_FullLicenseChecksum(std::string value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::string _CheckoutKey;
    UTCDateTime _ExpirationTime = UTCDateTime(DateTime());
    std::vector<std::string> _Features;
    std::vector<std::string> _FeatureGroups;
    std::string _FullLicenseJSON;
    FullLicense _FullLicense;
    std::string _FullLicenseChecksum;
};

class CheckInLicenseResult : public TimedServerResult
{
public:
    /// <summary>
    /// Gets whether the call succeeded.
    /// </summary>
    LICENSING_API bool get_Success() const;
    LICENSING_API void set_Success(bool value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    bool _Success;
};

class CheckOutComponentTokensResult : public ValidatedResult
{
public:
    /// <summary>
    /// Gets the key identifying the checkout.
    /// </summary>
    LICENSING_API std::string get_CheckoutKey();
    LICENSING_API void set_CheckoutKey(std::string value);

    /// <summary>
    /// Gets the time when the checkout expires.
    /// </summary>
    LICENSING_API UTCDateTime get_ExpirationTime();
    LICENSING_API void set_ExpirationTime(UTCDateTime value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    std::string _CheckoutKey;
    UTCDateTime _ExpirationTime = UTCDateTime(DateTime());
};

class CheckInComponentTokensResult : public TimedServerResult
{
public:
    /// <summary>
    /// Gets whether the call succeeded.
    /// </summary>
    LICENSING_API bool get_Success() const;
    LICENSING_API void set_Success(bool value);

    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
private:
    bool _Success;
};

#endif // ServerResultClasses_H
