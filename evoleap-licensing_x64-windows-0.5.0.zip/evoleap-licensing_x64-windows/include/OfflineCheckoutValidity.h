#pragma once
#include "SessionValidity.h"
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef OfflineCheckoutValidity_H
#define OfflineCheckoutValidity_H

using DateTime = std::chrono::system_clock::time_point;

class OfflineCheckoutValidity
{
public:
	/// <summary>
    /// Gets whether the current session should be allowed to continue.
    /// </summary>
    LICENSING_API bool get_Success();
    LICENSING_API void set_Success(bool value);

    /// <summary>
    /// Gets a value that indicates why the offline checkout did not succeed.
    /// </summary>
    LICENSING_API InvalidReason get_FailureReason();
    LICENSING_API void set_FailureReason(InvalidReason value);

    /// <summary>
    /// Gets the time when the offline checkout will expire, if the checkout was successful.
    /// </summary>
    LICENSING_API DateTime get_ExpirationTime();
    LICENSING_API void set_ExpirationTime(DateTime value);

	static LICENSING_API OfflineCheckoutValidity Invalid(InvalidReason reason);
	static LICENSING_API OfflineCheckoutValidity Valid(UTCDateTime expiration);
private:
    bool _Success = false;
    InvalidReason _FailureReason;
    DateTime _ExpirationTime;
};

#endif // OfflineCheckoutValidity_H