#pragma once
#include <string>
#include <vector>
#include "ComponentEntitlementInfo.h"
#include "ComponentInfo.h"
#include "IJsonSerializable.h"
#include "OfflineCheckoutInfo.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ReadOnlyCollection_H
#define ReadOnlyCollection_H

template<typename T> class LICENSING_API ReadOnlyCollectionBase
{
public:
	using Iterator = typename std::vector<T>::iterator;
	ReadOnlyCollectionBase();
	ReadOnlyCollectionBase(std::vector<T> list);
	~ReadOnlyCollectionBase();
	T operator[](int index);
	size_t get_Count();
	bool Contains(T item);
	void CopyTo(T array[], int index, int arrayLength);
	int IndexOf(T value);
	std::vector<T> ToVector();
	virtual Iterator begin();
	virtual Iterator end();
protected:
#pragma warning( disable : 4251 ) // The vector is internal to this class and not exposed, so we can safely ignore the warning.
	// std::vector<T> needs to have dll-interface to be used by clients of 'ReadOnlyCollection<T>'
	std::vector<T> Items;
#pragma warning( default : 4251 ) 

};

template<typename T, typename ENABLE = void> class LICENSING_API ReadOnlyCollection : public ReadOnlyCollectionBase<T>, public IJsonSerializable
{
public:
	ReadOnlyCollection();
	ReadOnlyCollection(std::vector<T> list);
	void Serialize(Json::Value& root) const override;
	void Deserialize(Json::Value& root) override;
};

template<> class LICENSING_API ReadOnlyCollection<std::string> : public ReadOnlyCollectionBase<std::string>, public  IJsonSerializable
{
public:
	ReadOnlyCollection();
	ReadOnlyCollection(std::vector<std::string> list);
	void Serialize(Json::Value& root) const override;
	void Deserialize(Json::Value& root) override;
};

template<> class LICENSING_API ReadOnlyCollection<int> : public ReadOnlyCollectionBase<int>, public IJsonSerializable
{
public:
	ReadOnlyCollection();
	ReadOnlyCollection(std::vector<int> list);
	void Serialize(Json::Value& root) const override;
	void Deserialize(Json::Value& root) override;
};

template<typename T> class LICENSING_API ReadOnlyCollection<T, typename std::enable_if<std::is_base_of<IJsonSerializable, T>::value>::type> 
	: public ReadOnlyCollectionBase<T>, public IJsonSerializable
{
public:
	ReadOnlyCollection();
	ReadOnlyCollection(std::vector<T> list);
	void Serialize(Json::Value& root) const override;
	void Deserialize(Json::Value& root) override;
};

template class LICENSING_API ReadOnlyCollectionBase<std::chrono::duration<double, std::milli>>;
template class LICENSING_API ReadOnlyCollectionBase<std::chrono::system_clock::time_point>;
template class LICENSING_API ReadOnlyCollectionBase<std::string>;

template class LICENSING_API ReadOnlyCollection<std::chrono::duration<double, std::milli>>;
template class LICENSING_API ReadOnlyCollection<std::chrono::system_clock::time_point>;
template class LICENSING_API ReadOnlyCollection<std::string>;

#endif // ReadOnlyCollection_H
