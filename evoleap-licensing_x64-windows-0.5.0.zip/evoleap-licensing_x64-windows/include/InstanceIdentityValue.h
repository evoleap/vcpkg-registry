#pragma once
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef InstanceIdentityValue_H
#define InstanceIdentityValue_H
class InstanceIdentityValue : public IJsonSerializable
{
public:
	static const bool DefaultCaseSensitive = true;
	static const int DefaultWeight = 1;
	static const int DefaultMaxArrayValueDifference = 1;

	LICENSING_API InstanceIdentityValue(std::string* value, bool caseSensitive = DefaultCaseSensitive, int weight = DefaultWeight, int maxArrayValueDifference = DefaultMaxArrayValueDifference);
	LICENSING_API InstanceIdentityValue(std::string value, bool caseSensitive = DefaultCaseSensitive, int weight = DefaultWeight, int maxArrayValueDifference = DefaultMaxArrayValueDifference);
	LICENSING_API InstanceIdentityValue(std::vector<std::string> values, bool caseSensitive = DefaultCaseSensitive, int weight = DefaultWeight, int maxArrayValueDifference = DefaultMaxArrayValueDifference);
	LICENSING_API InstanceIdentityValue();

	LICENSING_API bool get_IsArray() const;
	LICENSING_API bool get_CaseSensitive() const;
	LICENSING_API int get_Weight() const;
	LICENSING_API int get_MaxArrayValueDifference() const;
	LICENSING_API size_t get_ArraySize() const;
	LICENSING_API std::string get_StringValue() const;
	LICENSING_API std::string get_StringArrayValue(int index) const;

	LICENSING_API std::string ToString() const;
	LICENSING_API void Serialize(Json::Value& root) const override;
	LICENSING_API void Deserialize(Json::Value& root) override;
private:
	std::vector<std::string> stringArrayValue;
	bool _isArray;
	bool _caseSensitive;
	int _weight;
	int _maxArrayValueDifference;
};
#endif // InstanceIdentityValue_H
