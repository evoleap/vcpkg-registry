#pragma once
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ComponentCheckoutResult_H
#define ComponentCheckoutResult_H

#include "ComponentCheckoutFailureReason.h"

class ComponentCheckoutResult :
    public virtual IJsonSerializable
{
public:
    /// <summary>
    /// Gets a value indicating whether the component checkout was successful.
    /// </summary>
    LICENSING_API bool get_Success();

    /// <summary>
    /// Gets whether component checkouts were process offline (without communicating
    /// with the licensing server).
    /// </summary>
    LICENSING_API bool get_ProcessedOffline();
    LICENSING_API void set_ProcessedOffline(bool value);

    /// <summary>
    /// If component checkout failed, gets a value indicating why the checkout failed.
    /// </summary>
    LICENSING_API ComponentCheckoutFailureReason get_FailureReason();

    static LICENSING_API ComponentCheckoutResult GetSuccess(bool processedOffline);
    static LICENSING_API ComponentCheckoutResult GetFailure(ComponentCheckoutFailureReason reason, bool processedOffline);

    void LICENSING_API Serialize(Json::Value& root) const override;
    void LICENSING_API Deserialize(Json::Value& root) override;
private:
    bool _Success;
    bool _ProcessedOffline;
    ComponentCheckoutFailureReason _FailureReason;
	ComponentCheckoutResult(bool success, ComponentCheckoutFailureReason failureReason, bool processedOffline);
};

#endif // ComponentCheckoutResult_H