#pragma once
#include <string>
#include <map>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef UserInfo_H
#define UserInfo_H

class UserInfo
{
public:
	LICENSING_API UserInfo(std::string name, std::string email);
	LICENSING_API UserInfo(std::string name, std::string email, std::map<std::string, std::string> data);
	LICENSING_API ~UserInfo();
	LICENSING_API std::string get_Name();
	LICENSING_API std::string get_Email();
	LICENSING_API const std::map<std::string, std::string>& get_AdditionalData();
private:
	std::string _name;
	std::string _email;
	std::map<std::string, std::string> _additionalData;
	void Verify();
	friend class ControlManager;
};

#endif // UserInfo_H