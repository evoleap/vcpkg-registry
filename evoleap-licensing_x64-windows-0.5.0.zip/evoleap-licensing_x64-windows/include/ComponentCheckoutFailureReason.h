#pragma once

enum class LICENSING_API ComponentCheckoutFailureReason
{
    /// <summary>
    /// The reason is not known.
    /// </summary>
    Unknown = -1,
    /// <summary>
    /// The component checkout did not fail.
    /// </summary>
    NoFailure = 0,
    /// <summary>
    /// The server could not be reached.
    /// </summary>
    ServiceUnreachable,
    /// <summary>
    /// The system detected that the user is tampering with the system clock.
    /// </summary>
    UserTamperingDetected,
    /// <summary>
    /// Not enough session entitlements are available to complete the checkout.
    /// </summary>
    InsufficientSessions,
    /// <summary>
    /// Not enough tokens are available to complete the checkout.
    /// </summary>
    InsufficientTokens,
    /// <summary>
    /// One or more components is not included in this product version.
    /// </summary>
    InvalidComponent
};

LICENSING_API std::istream& operator>>(std::istream& is, ComponentCheckoutFailureReason& model);
LICENSING_API std::ostream& operator<<(std::ostream& os, ComponentCheckoutFailureReason model);


