#pragma once
#include <chrono>
#include <optional>
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef FullLicense_H
#define FullLicense_H

using DateTime = std::chrono::system_clock::time_point;

/// <summary>
/// Represents a record from elm with an ID, created, and updated time stamp
/// </summary>
class IElmRecord
{
public:
    /// <summary>
    /// Integer ID of elm record
    /// </summary>
    long get_Id() const;
    void set_Id(long value);
    /// <summary>
    /// Created date/time
    /// </summary>
    DateTime get_CreatedAt() const;
    void set_CreatedAt(DateTime value);
    /// <summary>
    /// Last updated date/time
    /// </summary>
    std::optional<DateTime> get_UpdatedAt() const;
    void set_UpdatedAt(std::optional<DateTime>  value);
private:
    long _Id;
    DateTime _CreatedAt;
    std::optional<DateTime> _UpdatedAt;
};

/// <summary>
/// The full, checked-out license
/// </summary>
class FullLicense : public IElmRecord, public virtual IJsonSerializable
{
public:
	// TODO: Fill out license. This is not actually used anywhere, so we can probably skip this until at some point we need it.
    LICENSING_API void Serialize(Json::Value& root) const override;
    LICENSING_API void Deserialize(Json::Value& root) override;
};

#endif // FullLicense_H
