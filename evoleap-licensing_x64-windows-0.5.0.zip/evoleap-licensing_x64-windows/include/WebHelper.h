#pragma once
#include <stduuid/uuid.h>
#include "RSACipher.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef WebHelper_H
#define WebHelper_H


class LICENSING_API WebHelper
{
public:
	static std::string GetData(HttpClient httpClient, std::string url);
	static std::string PostEncrypted(HttpClient &httpClient, const std::string &url, const uuids::uuid &instanceId, const Json::Value &postData, RSACipher &rsaCipher);
};

#endif // WebHelper_H
