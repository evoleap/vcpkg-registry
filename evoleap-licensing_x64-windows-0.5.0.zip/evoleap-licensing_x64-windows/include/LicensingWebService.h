#pragma once
#include <any>
#include <string>
#include <stduuid/uuid.h>
#include <json/json.h>
#include "ServerResults.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef LicensingWebService_H
#define LicensingWebService_H

class LicensingWebService :
    public virtual ILicensingWebService
{
    using Guid = uuids::uuid;
private:
    PublicKeyFile* _publicKey;
protected:
    CheckOutComponentResult CheckOutComponentsCommonAsync(Json::Value& postData, std::string uriPart, Guid productId);

    static void AddCommonData(Json::Value &postData,
        uuids::uuid productId, 
        InstanceIdentity* instanceIdentity, 
        UserIdentity* userIdentity, 
        UserInfo* userInfo)
    {
        WebServiceConstants constants;
        postData[constants.get().get_ProductGuid()] = uuids::to_string(productId);
        if (userIdentity != nullptr)
        {
            Json::Value userIdentityData;
            for (const auto& [key, value] : userIdentity->get_Data())
                userIdentityData[key] = value;
            userIdentityData[constants.get().Get("UserIdentityVersion")] =  2;
            postData[constants.get().get_UserIdentity()] = userIdentityData;
        }
        if (instanceIdentity != nullptr)
        {
            Json::Value instanceIdentityData;
            // Add behavior
            if (instanceIdentity->get_Version() != InstanceIdentity::DefaultVersion)
            {
                instanceIdentityData["_version"] = instanceIdentity->get_Version();
            }
            if (instanceIdentity->get_MaximumMismatchCount() != InstanceIdentity::DefaultMaximumMismatchCount)
            {
                instanceIdentityData["_max_mismatch_count"] = instanceIdentity->get_MaximumMismatchCount();
            }

            // Add keys
            for (const auto& [key, value] : (instanceIdentity->get_Values()))
            {
                Json::Value keyData(Json::objectValue);
                value.Serialize(keyData);
                instanceIdentityData[key] = keyData;
            }

            postData["instance_identity"] = instanceIdentityData;
        }
        if (userInfo != nullptr)
        {
            Json::Value userInfoData;
            userInfoData["name"] = userInfo->get_Name();
            userInfoData["email"] = userInfo->get_Email();
            userInfoData["additional_user_info"] = Json::Value();
            for (const auto& [key, value] : userInfo->get_AdditionalData())
            {
				userInfoData["additional_user_info"][key] = value;
            }
            postData["user_info"] = userInfoData;
        }
    }
public:
    LicensingWebService(PublicKeyFile* publicKey);
    RegisterAppResult RegisterAppAsync(
        uuids::uuid productId,
        std::string licenseKey,
        UserInfo userInfo,
        InstanceIdentity* instanceIdentity,
        UserIdentity userIdentity) override;
    BeginAppSessionResult BeginAppSessionAsync(
        Guid productId,
        Guid instanceId,
        Version instanceVersion, 
        std::optional<Guid> userId,
        InstanceIdentity* instanceIdentity = nullptr,
        UserIdentity* userIdentity = nullptr,
        std::optional<TimeSpan> requestedSessionDuration = std::optional<TimeSpan>()) override;
    ExtendSessionResult ExtendSessionAsync(Guid productId, std::string token, std::optional<TimeSpan> requestedExtensionDuration = std::optional<TimeSpan>()) override;
	EndSessionResult EndSessionAsync(Guid productId, std::string token) override;
	RegisterInstanceResult RegisterInstanceAsync(Guid productId, std::string licenseKey, InstanceIdentity* instanceIdentity) override;
	ValidateInstanceResult ValidateInstanceAsync(Guid productId, Guid instanceId, Version instanceVersion, InstanceIdentity* instanceIdentity = nullptr) override;
	ComponentsStatusResult GetComponentsStatusAsync(Guid productId, std::string sessionKey) override;
    CheckOutComponentResult CheckOutConsumableComponentAsync(Guid productId, std::string sessionKey, std::string component,
        std::optional<int> tokenCount = std::optional<int>()) override;
    CheckOutComponentResult CheckOutComponentsAsync(Guid productId, std::string sessionKey, std::vector<std::string> components) override;
    CheckInComponentResult CheckInComponentsAsync(Guid productId, std::string sessionKey, std::vector<std::string> components) override;
    CheckOutLicenseResult CheckOutLicenseAsync(
        Guid productId,
        Guid instanceId,
        Version instanceVersion,
        std::optional<Guid> userId,
        TimeSpan checkoutDuration,
        InstanceIdentity* instanceIdentity = nullptr,
        UserIdentity* userIdentity = nullptr,
        bool fullLicense = false) override;
	CheckInLicenseResult CheckInLicenseAsync(Guid productId, std::string checkoutKey) override;
    CheckOutComponentTokensResult CheckOutComponentTokensAsync(Guid productId, Guid instanceId, Version instanceVersion, std::optional<Guid> userId,
        int entitlementId, int tokenCount, TimeSpan checkoutDuration, InstanceIdentity* instanceIdentity = nullptr, UserIdentity* userIdentity = nullptr) override;
	CheckInComponentTokensResult CheckInComponentTokensAsync(Guid productId, std::string checkoutKey) override;
};

#endif // LicensingWebService_H