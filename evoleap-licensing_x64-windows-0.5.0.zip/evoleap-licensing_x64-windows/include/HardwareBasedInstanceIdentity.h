#pragma once
#include "InstanceIdentity.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef HardwareBasedInstanceIdentity_H
#define HardwareBasedInstanceIdentity_H

class HardwareBasedInstanceIdentity
{
public:
	static LICENSING_API InstanceIdentity& AddAllHardwareKeys(InstanceIdentity& identity);
	static LICENSING_API InstanceIdentity& AddHostName(InstanceIdentity& identity);
	static LICENSING_API InstanceIdentity& AddNetworkInfo(InstanceIdentity& identity);
	static LICENSING_API InstanceIdentity& AddCpuIdentifier(InstanceIdentity& identity);
	static LICENSING_API InstanceIdentity& AddVolumeHash(InstanceIdentity& identity);
private:
	static LICENSING_API InstanceIdentity& AddHostNameImpl(InstanceIdentity& identity);
	static LICENSING_API InstanceIdentity& AddNetworkInfoImpl(InstanceIdentity& identity);
	static LICENSING_API void AddCpuIdentifierImpl(InstanceIdentity& identity);
	static LICENSING_API void AddVolumeHashImpl(InstanceIdentity& identity);
};
#endif // HardwareBasedInstanceIdentity_H