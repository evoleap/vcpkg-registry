#pragma once
#include <iostream>
#include <json/json.h>
#include <sstream>
#include <string>
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IJsonSerializable_H
#define IJsonSerializable_H

class LICENSING_API IJsonSerializable
{
public:
	virtual ~IJsonSerializable() {};
	virtual void Serialize(Json::Value& root) const = 0;
	virtual void Deserialize(Json::Value& root) = 0;
	static std::string toDateString(UTCDateTime value);
	static UTCDateTime getDate(std::string rfc882Time);
	template<typename T> T getEnumValue(std::string value) const {
		std::istringstream ss(value);
		T result;
		ss >> result;
		return result;
	}
	template<typename T> std::string getEnumString(T value) const {
		std::ostringstream ss;
		ss << value;
		return ss.str();
	}
};

#endif // IJsonSerializable_H