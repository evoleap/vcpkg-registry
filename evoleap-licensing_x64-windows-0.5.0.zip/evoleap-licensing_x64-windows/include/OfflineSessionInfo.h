#pragma once
#include <chrono>
#include <optional>
#include <string>
#include <stduuid/uuid.h>
#include <vector>
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef OfflineSessionInfo_H
#define OfflineSessionInfo_H

class OfflineComponentCheckoutInfo : public IJsonSerializable {
public:
    using DateTime = std::chrono::system_clock::time_point;

    OfflineComponentCheckoutInfo();
    OfflineComponentCheckoutInfo(std::string component, UTCDateTime checkoutTime, int tokenCount);
    std::string get_Component();
    void set_Component(std::string value);
    DateTime get_CheckoutTime();
    void set_CheckoutTime(DateTime value);

    int get_TokenCount();
    void set_TokenCount(int value);

	bool operator==(const OfflineComponentCheckoutInfo& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    std::string _Component;
    DateTime _CheckoutTime;
    int _TokenCount;
};

class OfflineSessionInfo : public IJsonSerializable
{
public:
	using DateTime = std::chrono::system_clock::time_point;

    OfflineSessionInfo();

    // Note: this value is not sent to the server.  It is used to track the active
    // offline session across ControlManager instances.
    uuids::uuid get_LocalSessionId();
    void set_LocalSessionId(uuids::uuid value);

    // May be null.  Only set to a value for sessions that begin online then transfer later to offline mode.
    std::string get_SessionKey();
    void set_SessionKey(std::string value);

    std::optional<DateTime> get_StartTime();
    void set_StartTime(std::optional<DateTime> value);


    std::optional<DateTime> get_EndTime();
    void set_EndTime(std::optional<DateTime> value);
    std::vector<OfflineComponentCheckoutInfo> get_ComponentCheckouts();
    void set_ComponentCheckouts(std::vector<OfflineComponentCheckoutInfo> value);
    void AddComponentCheckout(OfflineComponentCheckoutInfo info);

    int get_UploadAttempts();
    void set_UploadAttempts(int value);

	bool operator==(const OfflineSessionInfo& other) const;

    // Internal:
    void set_UTCStartTime(std::optional<UTCDateTime> startTime);
    void set_UTCEndTime(std::optional<UTCDateTime> endTime);

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    uuids::uuid _LocalSessionId;
    std::string _SessionKey;
    std::optional<DateTime> _StartTime;
    std::optional<DateTime> _EndTime;
    std::vector<OfflineComponentCheckoutInfo> _ComponentCheckouts;
    int _UploadAttempts;
};

#endif // OfflineSessionInfo_H