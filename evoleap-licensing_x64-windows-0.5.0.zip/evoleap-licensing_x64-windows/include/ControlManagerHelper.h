#pragma once
#include <vector>
#include <functional>
#include "ControlState.h"
#include "ControlStrategy.h"
#include "InstanceValidity.h"
#include "IValidityFactory.h"
#include "SessionValidity.h"
#include "ServerResults.h"
#include "ServerState.h"
#include "UTCDateTime.h"

// NOTE: This file does not need to be part of the exports. Probably only files in pch.h

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ControlManagerHelper_H
#define ControlManagerHelper_H

using DateTime = std::chrono::system_clock::time_point;

enum OfflineGracePeriodStatus
{
    UserTamperingDetected,
    NotPermitted,
    Available
};

struct OfflineStatus {
    OfflineGracePeriodStatus status;
    std::optional<UTCDateTime> gracePeriodExpiration;
};

// Functions to help the control managers (was static class, but doesn't make sense in C++)

RegistrationResult RegisterImpl(ControlState* state, std::function<RegisterResultBase*()> registrationCallback, std::function<void(RegisterResultBase* ptr)> cleanUp);
void InitializeState(ControlState* state);
bool IsFirstLaunchTimeInvalid(UTCDateTime firstLaunchTime, UTCDateTime currentTime);
bool IsTimeInconsistencyDetected(UTCDateTime lastTrustedTime, ReadOnlyCollection<DateTime> previousTimes, UTCDateTime currentTime, bool currentTimeIsTrusted);
bool IsTimeInconsistencyDetected(ControlState state, UTCDateTime localTime);
bool IsInGracePeriodForUnregisteredProduct(ControlStrategy* controlStrategy, UTCDateTime firstLaunchTime, UTCDateTime currentTime, UTCDateTime* expiration);
void LogServerNotReached(ControlState* state, UTCDateTime localTime);
void LogServerReached(ControlState* state, UTCDateTime serverTime, ValidationStatus serverStatus);
OfflineStatus CheckOfflineStatus(ControlState* state, UTCDateTime localTime, bool updateLastValidationStatus = true);
InvalidReason StatusToReason(ValidationStatus status);
InstanceValidity ValidateInstanceAsync(
    ControlStrategy* strategy,
    ServerState* state,
    std::function<ValidateInstanceResult* ()> validateInstanceCallback,
    std::function<void(ValidateInstanceResult* ptr)> cleanUp);
template<typename T> bool Contains(std::vector<T> values, T value) {
    for (auto v : values) {
        if (v == value) {
			return true;
        }
    }
    return false;
}

template<typename TValidity> TValidity GetUnregisteredValidity(ControlStrategy* controlStrategy, ControlState* state,
	UTCDateTime currentTime, IValidityFactory<TValidity>& validityFactory) {
    // If we're not registered, the only way we could begin the session is if we're in the unregistered grace
    // period, as specified by the control strategy.

    // Also make sure the user isn't messing with time.
    if (IsFirstLaunchTimeInvalid(state->get_FirstLaunchTime(), currentTime))
    {
        state->set_LastValidationStatus(ValidationStatus::UserTamperingDetected);
        return validityFactory.Invalid(InvalidReason::UserTamperingDetected);
    }

	if (IsTimeInconsistencyDetected(state->get_FirstLaunchTime(), state->get_FailedRegistrationTimes(), currentTime, false))
	{
		state->set_LastValidationStatus(ValidationStatus::UserTamperingDetected);
		return validityFactory.Invalid(InvalidReason::UserTamperingDetected);
	}

    UTCDateTime* expiration = new UTCDateTime(DateTime());
    TValidity ret;
	if (IsInGracePeriodForUnregisteredProduct(controlStrategy, state->get_FirstLaunchTime(), currentTime, expiration))
	{
		ret = validityFactory.UnregisteredGracePeriod(*expiration);
	}
    else {
		state->set_LastValidationStatus(ValidationStatus::RegistrationRequired);
		ret = validityFactory.Invalid(InvalidReason::InstanceNotRegistered);
    }

    delete expiration;
    return ret;
}

template<typename TValidity> TValidity GetServerUnreachableValidity(ControlState* state, UTCDateTime localTime, IValidityFactory<TValidity>& validityFactory) {
    // The server was not contacted.  This is a failure unless we're in the grace period.  Also make sure
    // user is not messing with time.
	OfflineStatus offlineStatus = CheckOfflineStatus(state, localTime);
    if (offlineStatus.status == OfflineGracePeriodStatus::UserTamperingDetected)
        return validityFactory.Invalid(InvalidReason::UserTamperingDetected);
    else if (offlineStatus.status == OfflineGracePeriodStatus::NotPermitted)
        return validityFactory.Invalid(InvalidReason::ServiceUnreachable);
    else
        return validityFactory.ValidationFailureGracePeriod(offlineStatus.gracePeriodExpiration.value());
}

#endif // ControlManagerHelper_H

