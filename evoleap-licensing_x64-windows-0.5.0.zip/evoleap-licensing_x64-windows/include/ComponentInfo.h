#pragma once
#include <string>
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ComponentInfo_H
#define ComponentInfo_H

#include "ComponentLicenseModel.h"

class LICENSING_API ComponentInfo : public IJsonSerializable
{
public:
	using DateTime = std::chrono::system_clock::time_point;
    /**
    * Gets the name of the component
    */
    std::string get_Name() const;
    void set_Name(std::string value);
    /**
    * Gets the license model in force for the component.
    */
    ComponentLicenseModel get_LicenseModel() const;
    void set_LicenseModel(ComponentLicenseModel value);
    /**
    * Gets the number of tokens required to check out the component, if the
    *
    *  {@link #LicenseModel}
    *  property equals
    *  {@link #ComponentLicenseModel.Token}
    * .
    */
    int get_TokensRequired() const;
    void set_TokensRequired(int value);
    /**
    * Gets whether the component has a free trial defined.
    */
    bool get_HasFreeTrial() const;
    void set_HasFreeTrial(bool value);
    /**
    * Gets the time at which the free trial will expire.
    */
    DateTime get_FreeTrialExpirationTime() const;
    void set_FreeTrialExpirationTime(DateTime value);
    /**
    * Gets the number of tokens that would have been required to check out the
    * component if the free trial had not been active.
    */
    int get_OriginalTokensRequired() const;
    void set_OriginalTokensRequired(int value);
    int tokensRequiredAt(UTCDateTime time);

	bool operator==(const ComponentInfo& other) const;

    void Serialize(Json::Value& root) const override;
    void Deserialize(Json::Value& root) override;
private:
    ComponentLicenseModel __LicenseModel = ComponentLicenseModel::None;
    int __TokensRequired = 0;
    bool __FreeTrial = false;
#pragma warning(disable: 4251)
    std::string __Name;
    DateTime __FreeTrialExpirationTime;
#pragma warning(default: 4251)
    int __OriginalTokensRequired = 0;
};

#endif // ComponentInfo_H