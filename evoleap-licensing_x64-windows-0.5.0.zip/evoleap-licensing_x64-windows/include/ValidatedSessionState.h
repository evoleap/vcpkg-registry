#pragma once
#include "IValidatedSessionState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ValidatedSessionState_H
#define ValidatedSessionState_H

enum SessionState
{
    // These values are serialized so do not change them
    NotStarted = 0,
    Active = 1,
    Ended = 2,
    ActiveOffline = 3, // added in 4.0
    ActiveOfflineWithOnlineSession = 4, // added in 4.0
    ActiveOfflineCheckout = 5 // added in 5.0
};

class ValidatedSessionState :
    public IValidatedSessionState
{
public:
	ValidatedSessionState(IValidatedSessionState* state);
	ValidatedSessionState();
	~ValidatedSessionState();
	void set_AuthToken(std::string value);
	void set_SessionKey(std::string value);
    void set_SessionState(int value);
	void set_SessionState(SessionState value);
    SessionState get_SessionStateEnum();
	void set_OfflineCheckoutKey(std::string value);
	void set_OfflineSessionID(uuids::uuid value);
	std::vector<SessionOfflineTokenCheckoutInfo> get_OfflineTokenCheckoutsRW();
	void set_OfflineTokenCheckouts(std::vector<SessionOfflineTokenCheckoutInfo> value);
private:
	bool _cleanOfflineTokenCheckouts = false;
};

#endif // ValidatedSessionState_H                                      