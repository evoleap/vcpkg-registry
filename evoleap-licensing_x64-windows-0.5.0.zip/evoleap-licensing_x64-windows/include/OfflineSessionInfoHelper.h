#pragma once
#include <optional>
#include <string>
#include <stduuid/uuid.h>
#include "UTCDateTime.h"
#include "ValidationState.h"
#include "ValidatedSessionState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef OfflineSessionInfoHelper_H
#define OfflineSessionInfoHelper_H

using Guid = uuids::uuid;
Guid BeginOfflineSession(ValidationState* state, ValidatedSessionState* sessionState, std::optional<UTCDateTime> startTime, std::string serverSessionKey);
void EndOfflineSession(ValidationState* state, ValidatedSessionState* sessionState, std::optional<UTCDateTime> endTime);
#endif // OfflineSessionInfoHelper_H