#pragma once
#include <chrono>


#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef UTCDateTime_H
#define UTCDateTime_H

class UTCDateTime
{
public:
	/// <summary>
	/// Create a UTCDateTime from a system_clock::time_point
	/// </summary>
	/// <param name="time"></param>
	LICENSING_API UTCDateTime(std::chrono::system_clock::time_point time);
#if __cplusplus > 201703L

	/// <summary>
	/// Create a UTCDateTime from a utc_clock::time_point
	/// </summary>
	/// <param name="time"></param>
	LICENSING_API UTCDateTime(std::chrono::utc_clock::time_point& time);
#endif

	/// <summary>
	/// Create a UTCDateTime from a tm
	/// </summary>
	/// <param name="tm"></param>
	LICENSING_API UTCDateTime(const std::tm& tm);

	/// <summary>
	/// Copy constructor
	/// </summary>
	/// <param name="other"></param>
	LICENSING_API UTCDateTime(const UTCDateTime& other);

	/// <summary>
	/// Destructor
	/// </summary>
	LICENSING_API ~UTCDateTime();

	/// <summary>
	/// Overrides assignment operator to properly copy the time_point
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	LICENSING_API UTCDateTime& operator=(const UTCDateTime& other);

#if __cplusplus > 201703L
	/// <summary>
	/// Gets the time_point as a utc_clock::time_point
	/// </summary>
	/// <returns></returns>
	LICENSING_API const std::chrono::utc_clock::time_point& AsDateTime();
#else

	/// <summary>
	/// Gets the time_point as a system_clock::time_point
	/// </summary>
	/// <returns></returns>
	LICENSING_API std::chrono::system_clock::time_point& AsDateTime();
#endif

	LICENSING_API const std::chrono::duration<double, std::milli> operator-(const UTCDateTime& other) const;
	LICENSING_API const UTCDateTime operator+(const std::chrono::duration<double, std::milli>& duration) const;
	LICENSING_API const UTCDateTime operator-(const std::chrono::duration<double, std::milli>& duration) const;
	LICENSING_API const bool operator<(const UTCDateTime& other) const;
	LICENSING_API bool operator==(const UTCDateTime& other) const;

private:
#if __cplusplus > 201703L
	/// <summary>
	/// Managed pointer to the time_point
	/// </summary>
	std::chrono::utc_clock::time_point time_point;
#else
	/// <summary>
	/// Managed pointer to the time_point
	/// </summary>
	std::chrono::system_clock::time_point time_point;
#endif
};

#endif // !UTCDateTime_H