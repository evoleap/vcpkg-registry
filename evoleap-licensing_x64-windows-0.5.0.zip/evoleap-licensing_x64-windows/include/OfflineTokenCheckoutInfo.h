#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef OfflineTokenCheckoutInfo_H
#define OfflineTokenCheckoutInfo_H


class OfflineTokenCheckoutInfo
{
public:
	using DateTime = std::chrono::system_clock::time_point;

    LICENSING_API std::string get_CheckoutKey();
    LICENSING_API void set_CheckoutKey(std::string value);
    
    LICENSING_API DateTime get_Expiration();
    LICENSING_API void set_Expiration(DateTime value);
    
    LICENSING_API int get_EntitlementID();
    LICENSING_API void set_EntitlementID(int value);
    LICENSING_API int get_TokenCount();
    LICENSING_API void set_TokenCount(int value);
    
    LICENSING_API bool IsActive(UTCDateTime timeNow);
    LICENSING_API bool ShouldBeRemoved(UTCDateTime timeNow);
    
	LICENSING_API bool operator==(const OfflineTokenCheckoutInfo& other) const;
private:
    std::string _CheckoutKey;
    DateTime _Expiration;
    int _EntitlementID;
    int _TokenCount;
};

#endif // OfflineTokenCheckoutInfo_H