#pragma once
#include <mutex>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef DisallowReentrancyMarker_H
#define DisallowReentrancyMarker_H

class DisallowReentrancyMarker
{
public:
	DisallowReentrancyMarker(std::string message);
	~DisallowReentrancyMarker();
private:
	std::string _message;
	std::mutex _mutex;
	void Acquire();
	void Release();
	friend class ControlManager;
	friend class ServerControlManager;
};

#endif // DisallowReentrancyMarker_H
