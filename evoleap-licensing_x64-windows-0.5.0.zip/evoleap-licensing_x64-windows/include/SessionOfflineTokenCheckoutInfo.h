#pragma once
#include "IJsonSerializable.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef SessionOfflineTokenCheckoutInfo_H
#define SessionOfflineTokenCheckoutInfo_H

class LICENSING_API SessionOfflineTokenCheckoutInfo : public IJsonSerializable
{
public:

    SessionOfflineTokenCheckoutInfo();
    std::string getComponentName();
    void setComponentName(std::string value);
    std::string getOfflineTokenCheckoutKey();
    void setOfflineTokenCheckoutKey(std::string value);
    // Imagine an offline checkout of a component that costs tokens but has a free
    // trial period.  Storing the token cost at checkout is necessary to avoid over-counting
    // the number of tokens in use by a session if the checkout occurred before the
    // free trial period expired but a check of offline tokens in use occurs later in the
    // session after the free trial period has expired.
    int getTokenCostAtCheckout();
    void setTokenCostAtCheckout(int value);
	void Serialize(Json::Value& root) const override;
	void Deserialize(Json::Value& root) override;
	bool operator==(const SessionOfflineTokenCheckoutInfo& other) const;
private:
#pragma warning( disable : 4251 ) // The string is internal to this class and not exposed, so we can safely ignore the warning.
    std::string _componentName;
    std::string _offlineTokenCheckoutKey;
#pragma warning( default : 4251 )
    int _tokenCostAtCheckout;
};

template class LICENSING_API ReadOnlyCollection<SessionOfflineTokenCheckoutInfo>;


#endif // SessionOfflineTokenCheckoutInfo_H