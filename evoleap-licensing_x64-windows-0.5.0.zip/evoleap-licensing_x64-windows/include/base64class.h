#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef base64_H
#define base64_H

class LICENSING_API base64
{
public:
	base64(std::vector<unsigned char> buf);
	base64(std::string encodedText);
	std::string encode();
	std::vector<unsigned char> decode();
private:
	bool _isEncoded;
#pragma warning( disable : 4251 ) // The string/vector are internal to this class and not exposed, so we can safely ignore the warning.
	std::vector<unsigned char> _buf;
	std::string _encodedText;
#pragma warning( default : 4251 )
	bool _ranOther;
};

#endif
