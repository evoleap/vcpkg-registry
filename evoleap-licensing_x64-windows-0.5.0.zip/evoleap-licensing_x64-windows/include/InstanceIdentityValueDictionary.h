#pragma once
#include "ExtensibleDictionary.h"
#include "InstanceIdentityValue.h"
#include "ci_less.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef InstanceIdentityValueDictionary_H
#define InstanceIdentityValueDictionary_H

class LICENSING_API IInstanceIdentityValueDictionary {
public:
	virtual size_t get_Count() = 0;
	virtual void Add(std::string key, InstanceIdentityValue value) = 0;
	virtual InstanceIdentityValue operator[](std::string key) = 0;
};

template<class TComparer> class InstanceIdentityValueDictionary :
	ExtensibleDictionary<std::string, InstanceIdentityValue, TComparer>, public IInstanceIdentityValueDictionary
{
public:
	size_t get_Count() override;
	void Add(std::string key, InstanceIdentityValue value) override;
	InstanceIdentityValue operator[](std::string key) override;
	using MapType = std::map<std::string, InstanceIdentityValue, TComparer>;
	using Iterator = typename MapType::iterator;
	void insert(const std::string& key, const InstanceIdentityValue& value) override;
	Iterator begin() override;
	Iterator end() override;

protected:
	void AddItem(std::string key, InstanceIdentityValue value) override;
	void SetItem(std::string key, InstanceIdentityValue value) override;

	// Inherited via IInstanceIdentityValueDictionary
};

// This is actually implemented in the DLL, but you get about a million warnings about it not being implemented, so disabling the warning.
#pragma warning( disable : 4661 )

template class LICENSING_API InstanceIdentityValueDictionary<ci_less>;

#endif // InstanceIdentityValueDictionary_H
