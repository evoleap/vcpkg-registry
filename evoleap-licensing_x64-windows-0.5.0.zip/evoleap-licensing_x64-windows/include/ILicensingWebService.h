#pragma once
#include <string>
#include <vector>
#include <stduuid/uuid.h>
#include "InstanceIdentity.h"
#include "ServerResults.h"
#include "UserIdentity.h"
#include "UserInfo.h"
#include "Version.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ILicensingWebService_H
#define ILicensingWebService_H
class LICENSING_API ILicensingWebService
{
    using Guid = uuids::uuid;
public:
    /// <summary>
    /// Registers an instance and user with the license manager.
    /// </summary>
    /// <param name="productId">The unique identifier for this product</param>
    /// <param name="licenseKey">License key for the product</param>
    /// <param name="userInfo">Information about the user</param>
    /// <param name="userIdentity">Information about the user who is launching the product</param>
    /// <param name="instanceIdentity">Information about the instance on which this product is being launched</param>
    /// <returns>A unique identifier for this user of the product which needs to be used in subsequent calls to validate the license</returns>
    /// <remarks>Returns null if the service is unreachable or if it encounters another error. The consumer is free to choose what to do
    /// in case registration fails. Typical path forward might be to allow the user to continue to use the product for a fixed number of
    /// days before terminating the use of this product.</remarks>
    virtual RegisterAppResult RegisterAppAsync(
        uuids::uuid productId,
        std::string licenseKey,
        UserInfo userInfo,
        InstanceIdentity* instanceIdentity,
        UserIdentity userIdentity) = 0;
    virtual BeginAppSessionResult BeginAppSessionAsync(
        Guid productId,
        Guid instanceId,
        Version instanceVersion,
        std::optional<Guid> userId,
        InstanceIdentity* instanceIdentity = nullptr,
        UserIdentity* userIdentity = nullptr,
        std::optional<TimeSpan> requestedSessionDuration = std::optional<TimeSpan>()) = 0;
    virtual ExtendSessionResult ExtendSessionAsync(Guid productId, std::string token, std::optional<TimeSpan> requestedExtensionDuration = std::optional<TimeSpan>()) = 0;
	virtual EndSessionResult EndSessionAsync(Guid productId, std::string token) = 0;
    virtual RegisterInstanceResult RegisterInstanceAsync(Guid productId, std::string licenseKey, InstanceIdentity* instanceIdentity) = 0;
    virtual ValidateInstanceResult ValidateInstanceAsync(Guid productId, Guid instanceId, Version instanceVersion, InstanceIdentity* instanceIdentity = nullptr) = 0;
    virtual ComponentsStatusResult GetComponentsStatusAsync(Guid productId, std::string sessionKey) = 0;
    virtual CheckOutComponentResult CheckOutConsumableComponentAsync(
        Guid productId,
        std::string sessionKey,
        std::string component,
        std::optional<int> tokenCount = std::optional<int>()) = 0;
    virtual CheckOutComponentResult CheckOutComponentsAsync(Guid productId, std::string sessionKey, std::vector<std::string> components) = 0;
	virtual CheckInComponentResult CheckInComponentsAsync(Guid productId, std::string sessionKey, std::vector<std::string> components) = 0;
    virtual CheckOutLicenseResult CheckOutLicenseAsync(
        Guid productId,
        Guid instanceId,
        Version instanceVersion,
        std::optional<Guid> userId,
        TimeSpan checkoutDuration,
        InstanceIdentity* instanceIdentity = nullptr,
        UserIdentity* userIdentity = nullptr,
        bool fullLicense = false) = 0;
    virtual CheckInLicenseResult CheckInLicenseAsync(Guid productId, std::string checkoutKey) = 0;
    virtual CheckOutComponentTokensResult CheckOutComponentTokensAsync(Guid productId, Guid instanceId, Version instanceVersion, std::optional<Guid> userId,
        int entitlementId, int tokenCount, TimeSpan checkoutDuration, InstanceIdentity* instanceIdentity = nullptr, UserIdentity* userIdentity = nullptr) = 0;
    virtual CheckInComponentTokensResult CheckInComponentTokensAsync(Guid productId, std::string checkoutKey) = 0;
};

#endif // ILicensingWebService_H