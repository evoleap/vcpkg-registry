#pragma once
#include "UserIdentity.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ActiveDirectoryBasedUserIdentity_H
#define ActiveDirectoryBasedUserIdentity_H

class LICENSING_API ActiveDirectoryBasedUserIdentity
{
public:
	static UserIdentity GetCurrent();
};

#endif // ActiveDirectoryBasedUserIdentity_H