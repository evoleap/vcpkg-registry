#pragma once
#include <optional>
#include <stduuid/uuid.h>
#include <string>
#include "AppSessionManager.h"
#include "ComponentsStatus.h"
#include "ComponentCheckoutResult.h"
#include "ComponentCheckinResult.h"
#include "ControlStrategy.h"
#include "DisallowReentrancyMarker.h"
#include "ILicensingWebService.h"
#include "InstanceIdentity.h"
#include "IValidationState.h"
#include "IValidatedSessionState.h"
#include "OfflineCheckoutValidity.h"
#include "PublicKeyFile.h"
#include "RegistrationResult.h"
#include "ServerResults.h"
#include "SessionValidity.h"
#include "UserIdentity.h"
#include "UserInfo.h"
#include "ValidatedSessionState.h"
#include "ValidationState.h"
#include "Version.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ControlManager_H
#define ControlManager_H

using TimeSpan = std::chrono::duration<double, std::milli>;

class ControlManager
{
public:
	LICENSING_API ControlManager(
		uuids::uuid productId,
		Version version,
		PublicKeyFile* publicKey,
		UserIdentity userIdentity,
		InstanceIdentity& instanceIdentity,
		ControlStrategy* controlStrategy = nullptr,
		IValidationState* savedState = nullptr,
		IValidatedSessionState* sessionState = nullptr);
	LICENSING_API ControlManager(
		uuids::uuid productId,
		Version version,
		ILicensingWebService* webService,
		UserIdentity userIdentity,
		InstanceIdentity& instanceIdentity,
		ControlStrategy* controlStrategy = nullptr,
		IValidationState* savedState = nullptr,
		IValidatedSessionState* sessionState = nullptr);
	LICENSING_API ~ControlManager();
	LICENSING_API SessionValidity ValidateSession(std::optional<TimeSpan> requestedSessionDuration = TimeSpan());
	LICENSING_API bool EndSession();
	LICENSING_API ComponentsStatus GetComponentsStatus();
	LICENSING_API ComponentCheckoutResult CheckOutConsumableComponent(std::string componentName, std::optional<int> tokenCount = std::optional<int>());
	LICENSING_API ComponentCheckoutResult CheckOutComponents(std::string componentName);
	LICENSING_API ComponentCheckoutResult CheckOutComponents(std::vector<std::string> componentNames);
	LICENSING_API ComponentCheckinResult CheckInComponents(std::string componentNames);
	LICENSING_API ComponentCheckinResult CheckInComponents(std::vector<std::string> componentNames);
	LICENSING_API OfflineCheckoutValidity CheckOutLicenseForOfflineUseAsync(TimeSpan desiredCheckoutDuration);
	LICENSING_API bool CheckInOfflineLicenseAsync(std::string checkoutKey);
	LICENSING_API OfflineCheckoutValidity CheckOutComponentTokensForOfflineUseAsync(int componentEntitlementID, int tokenCount, TimeSpan desiredCheckoutDuration);
	LICENSING_API bool CheckInOfflineComponentTokensAsync(std::string checkoutKey);

	// No making copies implicitly. Pass by reference.
	ControlManager(const ControlManager&) = delete;
	ControlManager& operator=(const ControlManager&) = delete;
	LICENSING_API RegistrationResult Register(std::string licenseKey, UserInfo userInfo);
	virtual LICENSING_API ILicensingWebService* get_LicensingWebService(PublicKeyFile* publicKey);
	/// <summary>
	/// Return a copy of the validation state object that must be deleted when complete using the deleteValidationState method only.
	/// </summary>
	/// <returns></returns>
	LICENSING_API IValidationState* get_newValidationState();
	LICENSING_API void deleteValidationState(IValidationState* validation);
	/// <summary>
	/// Return a copy of the session state object that must be deleted when complete using the deleteSessionState method only.
	/// </summary>
	/// <returns></returns>
	LICENSING_API IValidatedSessionState* get_newSessionState();
	LICENSING_API void deleteSessionState(IValidatedSessionState* sessionState);
private:
	ILicensingWebService* _webService;
	bool _ownWebService = false;
	uuids::uuid _productId;
	Version _version;
	UserIdentity _userIdentity;
	InstanceIdentity& _instanceIdentity;
	DisallowReentrancyMarker _reentrancyMarker;
	bool _ownControlStrategy = false;
	ControlStrategy* _controlStrategy;
	ValidationState* _state;
	ValidatedSessionState* _sessionState;
	RegisterResultBase* RegisterCore(std::string licenseKey, UserInfo userInfo);
	void EnsureWebSessionManagerCreated();
	AppSessionManager* _sessionManager;
};

#endif // ControlManager_H