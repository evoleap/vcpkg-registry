#pragma once
#include <map>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef WebServiceConstants_H
#define WebServiceConstants_H

class WebServiceConstantsImpl{

private:
    std::map<std::string, std::map<std::string, std::string>> _magicStrings;
    std::string _currentVersion = "3.4";
public:
    LICENSING_API WebServiceConstantsImpl();
    std::string Get(std::string key, std::string version = std::string());
    std::string get_Duration(std::string version = std::string());
    std::string get_LicenseKey(std::string version = std::string());
    std::string get_InstanceGuid(std::string version = std::string());
    std::string get_Version(std::string version = std::string());
    std::string get_ProductGuid(std::string version = std::string());
    std::string get_UserIdentity(std::string version = std::string());
    // Results constants   
    std::string get_ResultAuthToken(std::string version = std::string());
    std::string get_ResultIsSuccess(std::string version = std::string());
    std::string get_ResultTime(std::string version = std::string());
    std::string get_ResultInstanceGuid(std::string version = std::string());
    std::string get_ResultUserGuid(std::string version = std::string());
    std::string get_ResultErrorMessage(std::string version = std::string());
    std::string get_ResultStatus(std::string version = std::string());
    std::string get_ResultFeatures(std::string version = std::string());
    std::string get_ResultFeatureGroups(std::string version = std::string());
    std::string get_ResultFirstRegisteredAt(std::string version = std::string());
    std::string get_LicenseExpiry(std::string version = std::string());
    std::string get_OwnerName(std::string version = std::string());
    std::string get_OwnerLogoUrl(std::string version = std::string());
    std::string get_UserIdentityVersion(std::string version = std::string());
    std::string get_FullLicense(std::string version = std::string());
    std::string get_FullLicenseChecksum(std::string version = std::string());
    std::string get_PublicKey(std::string version = std::string());
    std::string get_SessionKey(std::string version = std::string());
    std::string get_Component(std::string version = std::string());
    std::string get_TokenCount(std::string version = std::string());
    std::string get_Components(std::string version = std::string());
};

class LICENSING_API WebServiceConstants {
public:
    WebServiceConstants();
    WebServiceConstantsImpl& get();
private:
    static WebServiceConstantsImpl& impl();
    WebServiceConstantsImpl& impl_;
};

#endif // WebServiceConstants_H