#pragma once

#include "InstanceIdentityValueDictionary.h"
#include "ci_less.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef InstanceIdentity_H
#define InstanceIdentity_H

class LICENSING_API InstanceIdentity
{
public:
	static const int DefaultVersion = 1;
	static const int DefaultMaximumMismatchCount = 1;
	InstanceIdentity(std::vector<std::pair<std::string, InstanceIdentityValue>> values = { }, int version = DefaultVersion, int maximumMismatchCount = DefaultMaximumMismatchCount);
	~InstanceIdentity();
	InstanceIdentity(const InstanceIdentity& other) = delete;
	InstanceIdentity& operator=(const InstanceIdentity& other) = delete;
	InstanceIdentityValueDictionary<ci_less>& get_Values();
	int get_Version();
	int get_MaximumMismatchCount();
private:
	IInstanceIdentityValueDictionary* _values;
	int _version;
	int _maximumMismatchCount;
};
#endif // InstanceIdentity_H
