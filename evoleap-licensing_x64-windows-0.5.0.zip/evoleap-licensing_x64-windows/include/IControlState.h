#pragma once
#include <string>
#include "ReadOnlyCollection.h"
#include <chrono>
#include <optional>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IControlState_H
#define IControlState_H

class LICENSING_API IControlState
{
public:
        /// <summary>
        /// Gets a flag indicating if this instance has been
        /// registered
        /// </summary>
        virtual bool get_Registered() = 0;
        /// <summary>
        /// Gets the times at which registration of the instance was 
        /// attempted with the licensing server
        /// </summary>
        virtual ReadOnlyCollection<std::chrono::system_clock::time_point> get_FailedRegistrationTimes() = 0;
        /// <summary>
        /// Gets the time at which the instance was first
        /// registered with the licensing server
        /// </summary>
        virtual std::optional<std::chrono::system_clock::time_point> get_RegisteredAt() = 0;
        /// <summary>
        /// Gets the time from NIST when this object is constructed using
        /// the default constructor. 
        /// </summary>
        virtual std::chrono::system_clock::time_point get_FirstLaunchTime() = 0;
        /// <summary>
        /// Gets the times at which the license validation failed
        /// </summary>
        virtual ReadOnlyCollection<std::chrono::system_clock::time_point> get_FailedValidationTimes() = 0;
        /// <summary>
        /// Gets the last time the server was successfully contacted during a validation.
        /// </summary>
        virtual std::optional<std::chrono::system_clock::time_point> get_LastSuccessfulValidationTime() = 0;
        /// <summary>
        /// Status returned by the last successful validation call to the licensing
        /// web service
        /// </summary>
        virtual int get_LastValidationStatus() = 0;
        /// <summary>
        /// A list of features permitted by the license
        /// </summary>
        virtual ReadOnlyCollection<std::string> get_Features() = 0;
        /// <summary>
        /// A list of feature groups permitted by the license
        /// </summary>
        virtual ReadOnlyCollection<std::string> get_FeatureGroups() = 0;
        /// <summary>
        /// Gets the length of time access should be granted while unable to contact the licensing server.
        /// </summary>
        virtual std::chrono::duration<double, std::milli> get_GracePeriodForValidationFailures() = 0;

};

#endif // IControlState_H