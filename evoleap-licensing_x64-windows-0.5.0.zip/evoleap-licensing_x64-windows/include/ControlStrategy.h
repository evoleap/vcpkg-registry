#pragma once
#include <chrono>

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ControlStrategy_H
#define ControlStrategy_H

class ControlStrategy
{
public:
	LICENSING_API ControlStrategy();
	void LICENSING_API set_GracePeriodForUnregisteredProduct(std::chrono::duration<double, std::milli> value);
	std::chrono::duration<double, std::milli> LICENSING_API get_GracePeriodForUnregisteredProduct();
	void LICENSING_API Lock();
private:
	bool _locked;
	std::chrono::duration<double, std::milli> _gracePeriod;
};

#endif // ControlStrategy_H
