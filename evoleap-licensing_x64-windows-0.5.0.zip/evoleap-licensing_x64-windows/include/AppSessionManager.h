#pragma once
#include <functional>
#include <optional>
#include <stduuid/uuid.h>
#include "ComponentCheckoutResult.h"
#include "ComponentCheckinResult.h"
#include "ComponentsStatus.h"
#include "ILicensingWebService.h"
#include "InstanceIdentity.h"
#include "OfflineTokenCheckoutInfo.h"
#include "ReadOnlyCollection.h"
#include "ServerResults.h"
#include "SessionOfflineTokenCheckoutInfo.h"
#include "SessionValidity.h"
#include "UserIdentity.h"
#include "Version.h"
#include "ValidationState.h"
#include "ValidatedSessionState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef AppSessionManager_H
#define AppSessionManager_H

enum ValidationResult
{
    OnlineSuccess,
    OnlineFailure,
    OfflineSuccess,
    OfflineFailure,
    OfflineFailureUserTampering,
};

template class ReadOnlyCollectionBase<SessionOfflineTokenCheckoutInfo>;
template class ReadOnlyCollectionBase<OfflineTokenCheckoutInfo>;

class AppSessionManager
{
public:
    AppSessionManager(
        ILicensingWebService* webService,
        uuids::uuid productId,
        Version version,
        ValidationState* validationState,
        ValidatedSessionState* sessionState,
        InstanceIdentity* instanceIdentity = nullptr,
        UserIdentity* userIdentity = nullptr);
    SessionValidity BeginSession(std::optional<TimeSpan> requestedSessionDuration);
	SessionValidity ExtendSession(std::optional<TimeSpan> requestedSessionDuration);
    ComponentsStatus GetComponentsStatus();
    ComponentCheckoutResult CheckOutConsumableComponent(std::string component, std::optional<int> tokenCount = std::optional<int>());
    ComponentCheckoutResult CheckOutComponents(std::string components);
    ComponentCheckoutResult CheckOutComponents(std::vector<std::string> components);
    ComponentCheckinResult CheckInComponentsAsync(std::vector<std::string> components);
    bool IsUsingLicenseCheckout(std::string checkoutKey);
    bool IsUsingComponentTokenCheckout(std::string checkoutKey);
    bool EndSession();
private:
    ILicensingWebService* _webService;
    uuids::uuid _productId;
    Version _version;
    ValidationState* _validationState;
    ValidatedSessionState* _sessionState;
    InstanceIdentity* _instanceIdentity;
    UserIdentity* _userIdentity;
    SessionValidity ProcessWebResultIntoValidity(ValidatedSessionResult webResult, ValidationResult* result);
    BeginAppSessionResult BeginWebSessionAsync(std::optional<TimeSpan> requestedSessionDuration = std::optional<TimeSpan>());
    ExtendSessionResult ExtendWebSessionAsync(std::optional<TimeSpan> requestedExtensionDuration = std::optional<TimeSpan>());
    ComponentCheckoutResult CheckOutComponentsCommon(std::string component, std::function<CheckOutComponentResult()> webResultGetter);
    ComponentCheckoutResult CheckOutComponentsCommon(std::vector<std::string> components, std::function<CheckOutComponentResult()> webResultGetter);
    ComponentCheckoutResult CheckOutFreeComponentsOffline(std::string componentName, ComponentCheckoutFailureReason failureReason);
    ComponentCheckoutResult CheckOutFreeComponentsOffline(std::vector<std::string> componentName, ComponentCheckoutFailureReason failureReason);
};

#endif // AppSessionManager_H