#pragma once
#include "SessionValidity.h"
#include "UTCDateTime.h"

using DateTime = std::chrono::system_clock::time_point;

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef InstanceValidity_H
#define InstanceValidity_H

class InstanceValidity
{
public:
	LICENSING_API InstanceValidity();
	LICENSING_API ~InstanceValidity();
	LICENSING_API bool get_IsValid();
	LICENSING_API void set_IsValid(bool value);
	LICENSING_API InvalidReason get_InvalidateReason();
	LICENSING_API void set_InvalidateReason(InvalidReason value);
	LICENSING_API bool get_IsInValidationFailureGracePeriod();
	LICENSING_API void set_IsInValidationFailureGracePeriod(bool value);
	LICENSING_API bool get_IsInUnregisteredGracePeriod();
	LICENSING_API void set_IsInUnregisteredGracePeriod(bool value);
	LICENSING_API DateTime get_GracePeriodExpiration();
	LICENSING_API void set_GracePeriodExpiration(DateTime value);
// internal:
	static InstanceValidity Invalid(InvalidReason reason);
	static InstanceValidity Valid();
	static InstanceValidity UnregisteredGracePeriod(UTCDateTime expiration);
	static InstanceValidity ValidationFailureGracePeriod(UTCDateTime expiration);
private:
	bool _isValid;
	InvalidReason _invalidateReason;
	bool _isInValidationFailureGracePeriod;
	bool _isInUnregisteredGracePeriod;
	DateTime _gracePeriodExpiration;
};

#endif // InstanceValidity_H