#pragma once
#include <stduuid/uuid.h>
#include "OfflineSessionInfo.h"
#include "ComponentEntitlementInfo.h"
#include "ComponentInfo.h"
#include "OfflineCheckoutInfo.h"
#include "OfflineTokenCheckoutInfo.h"
#include "SessionControlState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef IValidationState_H
#define IValidationState_H

class LICENSING_API IValidationState : virtual public ISessionControlState
{
public:
    using Guid = uuids::uuid;
    /// <summary>
    /// Gets the instance id from the licensing server
    /// </summary>
    Guid get_InstanceId();
    /// <summary>
    /// Gets whether the user id is available in this state object.
    /// </summary>
    bool get_HasUserId();
    /// <summary>
    /// Gets the user id from the licensing server
    /// </summary>
    Guid get_UserId();
    /// <summary>
    /// Gets whether the components collection has been loaded by a successful licensing call.
    /// </summary>
    bool get_ComponentsLoaded();
    /// <summary>
    /// A list of components made available to the license
    /// </summary>
    ReadOnlyCollection<ComponentInfo> get_Components();
    /// <summary>
    /// Gets whether the component entitlements collection has been loaded by a successful licensing call.
    /// </summary>
    bool get_ComponentEntitlementsLoaded();
    /// <summary>
    /// A list of component entitlements that apply to the license.
    /// </summary>
    ReadOnlyCollection<ComponentEntitlementInfo> get_ComponentEntitlements();
    /// <summary>
    /// A list of all offline checkouts.
    /// </summary>
    ReadOnlyCollection<OfflineCheckoutInfo> get_OfflineCheckouts();
    /// <summary>
    /// A list of all offline token checkouts.
    /// </summary>
    ReadOnlyCollection<OfflineTokenCheckoutInfo> get_OfflineTokenCheckouts();
    /// <summary>
    /// A list of all offline sessions.
    /// </summary>
    ReadOnlyCollection<OfflineSessionInfo> get_OfflineSessions();
protected:
#pragma warning(disable: 4251)
	Guid _instanceId;
	Guid _userId;
#pragma warning(default: 4251)
    bool _hasUserId = false;
	bool _componentsLoaded = false;
	bool _componentEntitlementsLoaded = false;
	ReadOnlyCollection<ComponentInfo> _components;
	ReadOnlyCollection<ComponentEntitlementInfo> _componentEntitlements;
	ReadOnlyCollection<OfflineCheckoutInfo> _offlineCheckouts;
	ReadOnlyCollection<OfflineTokenCheckoutInfo> _offlineTokenCheckouts;
	ReadOnlyCollection<OfflineSessionInfo> _offlineSessions;
};

#endif // IValidationState_H