#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef EventArgs_H
#define EventArgs_H

class LICENSING_API EventArgs {
public:
	static EventArgs Empty();
	EventArgs();
};
LICENSING_API typedef void (*EventHandler)(void* sender, EventArgs args);

#endif // EventArgs_H