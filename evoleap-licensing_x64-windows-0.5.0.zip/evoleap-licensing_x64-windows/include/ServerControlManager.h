#pragma once
#include <string>
#include <stduuid/uuid.h>
#include "DisallowReentrancyMarker.h"
#include "ILicensingWebService.h"
#include "InstanceIdentity.h"
#include "InstanceValidity.h"
#include "IServerState.h"
#include "OfflineCheckoutValidity.h"
#include "PublicKeyFile.h"
#include "RegistrationResult.h"
#include "ServerResults.h"
#include "ServerState.h"
#include "Version.h"


#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef ServerControlManager_H
#define ServerControlManager_H

using TimeSpan = std::chrono::duration<double, std::milli>;

class ServerControlManager
{
public:
	using Guid = uuids::uuid;
    LICENSING_API ServerControlManager(
        Guid productId,
        Version version,
        PublicKeyFile* publicKey,
        ControlStrategy* controlStrategy = nullptr,
        IServerState* savedState = nullptr);
    LICENSING_API ServerControlManager(
        Guid productId,
        Version version,
        ILicensingWebService* webService,
        PublicKeyFile* publicKey,
        ControlStrategy* controlStrategy = nullptr,
        IServerState* savedState = nullptr);
	LICENSING_API ~ServerControlManager();

    /// <summary>
    /// Gets the product id.
    /// </summary>
    LICENSING_API Guid get_ProductId() const;
    /// <summary>
    /// Gets the current validation state of the program. Use this to retrieve
    /// the validation state for persistence.
    /// </summary>
    LICENSING_API IServerState* get_ServerState();
    /// <summary>
    /// Gets or sets the control strategy to be used
    /// </summary>
    LICENSING_API ControlStrategy* get_Strategy();
    /// <summary>
    /// Public Key File from Public Constructor
    /// </summary>
    LICENSING_API PublicKeyFile* get_PublicKeyFile();

    /// <summary>
    /// Registers this product instance with the licensing web service
    /// </summary>
    /// <param name="licenseKey">The license key</param>
    /// <param name="instanceIdentity">The instance's identity</param>
    /// <returns>true if registration is successful</returns>
    LICENSING_API RegistrationResult Register(std::string licenseKey, InstanceIdentity* instanceIdentity);

    /// <summary>
    /// Validates this product instance with the licensing web service. The result of the validation
    /// query can be obtained from the <see cref="IControlState.LastValidationStatus"/> property
    /// </summary>
    /// <param name="instanceIdentity">The current instance's identity.  If not null, the server will verify that the current identity matches the identity used when the server was registered.</param>
    LICENSING_API InstanceValidity ValidateInstance(InstanceIdentity* instanceIdentity);

    LICENSING_API OfflineCheckoutValidity CheckOutLicenseForOfflineUseAsync(TimeSpan desiredCheckoutDuration);
    LICENSING_API bool CheckInOfflineLicenseAsync(std::string checkoutKey);

private:
	ServerState* _state;
	Guid _productId;
	Version _version;
	ILicensingWebService* _webService;
	DisallowReentrancyMarker _reentrancyMarker;
	ControlStrategy* _strategy;
	PublicKeyFile* _publicKeyFile;
    bool _ownControlStrategy;
    bool _ownLicensingWebService = false;
    InstanceIdentity* _instanceIdentity = nullptr;

    RegisterResultBase* RegisterCore(std::string licenseKey, InstanceIdentity* instanceIdentity);
};

#endif // ServerControlManager_H