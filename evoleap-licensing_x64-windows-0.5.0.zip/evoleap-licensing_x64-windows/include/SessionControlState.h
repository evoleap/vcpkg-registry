#pragma once
#include "ControlState.h"
#include "IControlState.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef SessionControlState_H
#define SessionControlState_H

class LICENSING_API ISessionControlState : virtual public IControlState
{
public:
    virtual std::chrono::duration<double, std::milli> get_SessionDuration() = 0;
};
#pragma warning(disable: 4250) // The ControlState implementation of IControlState is inherited by SessionControlState, overriding the virtual functions
                               // in ISessionControlState/IControlState. This warning is disabled because it is by design.
class SessionControlState :
    public ControlState, virtual public ISessionControlState
{
public:
    SessionControlState();
    SessionControlState(ISessionControlState* other);
    void AdditionalUpdateAfterRegistrationSuccess(RegisterResultBase* result) override;

    // Inherited via ISessionControlState
    std::chrono::duration<double, std::milli> get_SessionDuration() override;
	void set_SessionDuration(std::chrono::duration<double, std::milli> value);
private:
    std::chrono::duration<double, std::milli> _sessionDuration;
};
#pragma warning(default: 4250)

#endif // SessionControlState_H