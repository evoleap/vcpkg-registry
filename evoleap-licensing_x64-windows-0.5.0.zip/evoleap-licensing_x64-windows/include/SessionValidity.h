#pragma once
#include <chrono>
#include "ReadOnlyCollection.h"
#include "ServerResults.h"
#include "UTCDateTime.h"

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef SessionValidity_H
#define SessionValidity_H

enum class LICENSING_API InvalidReason {
    /// <summary>
    /// The reason is not known.
    /// </summary>
    Unknown = -1,

    /// <summary>
    /// The session was valid
    /// </summary>
    NotInvalid = 0, // must be default value

    /// <summary>
    /// The system detected that the user is tampering with the system clock.
    /// </summary>
    UserTamperingDetected,

    /// <summary>
    /// The server could not be reached and the grace period does not apply.
    /// </summary>
    ServiceUnreachable,

    /// <summary>
    /// The license has expired.
    /// </summary>
    LicenseExpired,

    /// <summary>
    /// The session has been remotely revoked.
    /// </summary>
    SessionRevoked,

    /// <summary>
    /// No open seats are available.
    /// </summary>
    NoSeatsAvailable,

    /// <summary>
    /// The current machine information does not match the information used when the instance was registered.
    /// </summary>
    InconsistentRegistration,

    /// <summary>
    /// The current user information does not match the information used when the instance was registered.
    /// </summary>
    InconsistentUser,

    /// <summary>
    /// The current instance is not registered.
    /// </summary>
    InstanceNotRegistered,

    /// <summary>
    /// The current user is not registered.
    /// </summary>
    UserNotRegistered,

    /// <summary>
    /// The license key is not valid.
    /// </summary>
    InvalidLicenseKey,

    /// <summary>
    /// The product id is not valid.
    /// </summary>
    InvalidProductId,

    /// <summary>
    /// The current instance has been disabled.
    /// </summary>
    InstanceDisabled,

    /// <summary>
    /// The current user has been disabled.
    /// </summary>
    UserDisabled,

    /// <summary>
    /// The current instance has been registered but is not activated.
    /// </summary>
    ActivationPending,

    /// <summary>
    /// The offline checkout used to start the session has expired.
    /// </summary>
    OfflineCheckoutExpired,

    /// <summary>
    /// An attempt was made to check out a license for offline use when that license does
    /// not support offline checkouts.
    /// </summary>
    OfflineCheckoutNotSupported,

    /// <summary>
    /// Not enough tokens are available to complete the licensing request.
    /// </summary>
    InsufficientTokens,

    /// <summary>
    /// Full license has already been checked out and is still active
    /// </summary>
    FullLicenseAlreadyCheckedOut,
};

LICENSING_API std::istream& operator>>(std::istream& is, InvalidReason& model);
LICENSING_API std::ostream& operator<<(std::ostream& os, InvalidReason model);

using InvalidReasonType = InvalidReason;
using TimeSpan = std::chrono::duration<double, std::milli>;

struct LICENSING_API SessionValidity {
    /// <summary>
    /// Gets whether the current session should be allowed to continue.
    /// </summary>
    bool IsValid;
    /// <summary>
    /// Gets a value that indicates why a session is not valid.
    /// </summary>
    InvalidReasonType InvalidReason;
    /// <summary>
    /// Gets whether the session is valid because it is in the unvalidated grace period.
    /// </summary>
    bool IsInValidationFailureGracePeriod;
    /// <summary>
    /// Gets whether the session is valid because it is in the unregistered grace period.
    /// </summary>
    bool IsInUnregisteredGracePeriod;
    /// <summary>
    /// Gets whether the session is valid because of an offline license checkout.
    /// </summary>
    bool IsOfflineCheckout;
    /// <summary>
    /// If the session is invalid, gets whether an expired offline checkout is available.  This allows clients to customize an error
    /// message when validation fails due to the server being unavailable *and* the user's offline checkout
    /// has expired.
    /// </summary>
    bool HasExpiredOfflineCheckout;
    SessionValidity();
    ~SessionValidity();
	SessionValidity(const SessionValidity&);
    SessionValidity& operator=(const SessionValidity&);
	std::chrono::system_clock::time_point* get_GracePeriodExpiration();
	void set_GracePeriodExpiration(std::chrono::system_clock::time_point* value);
	std::chrono::duration<double, std::milli>* get_ValidityDuration();
	void set_ValidityDuration(std::chrono::duration<double, std::milli>* value);
	static SessionValidity Invalid(InvalidReasonType reason, bool hasExpiredOfflineCheckout);
	static SessionValidity Valid(TimeSpan* validityDuration);
	static SessionValidity UnregisteredGracePeriod(UTCDateTime expiration);
	static SessionValidity ValidationFailureGracePeriod(UTCDateTime expiration);
	static SessionValidity OfflineCheckout(UTCDateTime expiration);
private:
    /// <summary>
    /// Gets the length of time remaining in the grace period.
    /// </summary>
    std::chrono::system_clock::time_point* _gracePeriodExpiration;
    /// <summary>
    /// Gets the length of time the session will remain valid.
    /// </summary>
    std::chrono::duration<double, std::milli>* _validityDuration;
};

/// <summary>
/// Get a pointer to new duration based on the seconds passed. The memory will need to be freed by the caller.
/// </summary>
/// <param name="seconds"></param>
/// <returns></returns>
extern LICENSING_API std::chrono::duration<double, std::milli>* GetDuration(int seconds);
extern LICENSING_API SessionValidity SessionValidity_Invalid(InvalidReason reason, bool hasExpiredOfflineCheckout);
extern LICENSING_API SessionValidity SessionValidity_Valid(std::chrono::duration<double, std::milli>* validityDuration);

#endif // SessionValidity_H