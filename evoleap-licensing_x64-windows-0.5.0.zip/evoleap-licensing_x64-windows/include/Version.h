#pragma once

#ifdef EVOLEAPLICENSING_EXPORTS
#define LICENSING_API __declspec(dllexport)
#else
#define LICENSING_API __declspec(dllimport)
#endif

#ifndef Version_H
#define Version_H

class LICENSING_API Version
{
public:
	Version();
	Version(std::string string);
	std::string toString() const;
private:
	int _major;
	int _minor;
	int _revision;
	int _build;
	size_t _versionParts;
};

#endif // Version_H
