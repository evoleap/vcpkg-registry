#pragma once
#include <istream>
#include <ostream>

enum class LICENSING_API ComponentLicenseModel
{
    /**
    * An enumeration of the different license models available for components
    *
    * The component is not licensed.  There are no licensing
    * restrictions placed on its use.
    */
    None,
    /**
    * The component is licensed by tokens.  A specified number of
    * tokens are required in order to check out the component.
    */
    Token,
    /**
    * The component is licensed by sessions.  Only a specified number
    * of sessions can check out the component at one time.
    */
    Session,
    /**
    * The component is license by tokens. A specified number of
    * tokens are required to checkout the component. Tokens are
    * conusmed when used
    */
    ConsumableToken,
    /**
    * The license model was not understood by this client API.  This
    * might happen if a new license model is introduced and implemented
    * in the licensing portal, but the application is not updated to
    * support it.
    */
    Unknown,
};

LICENSING_API std::istream& operator>>(std::istream& is, ComponentLicenseModel& model);
LICENSING_API std::ostream& operator<<(std::ostream& os, ComponentLicenseModel model);

